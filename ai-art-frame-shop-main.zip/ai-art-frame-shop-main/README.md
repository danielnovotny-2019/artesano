# [LIve Site](https://ai-art-to-frame.netlify.app/)

# [GitHub repo Frontend](https://github.com/ND-Morsalin/ai-art-frame-shop)
# [GitHub repo backend](https://github.com/ND-Morsalin/ai-art-frame-server)

--- 
# Where is need to change when switching local and development.
---
### For Server 

### For Client

1. change server url inside axiosInstance file
```sh
src\utility\axiosInstace.ts
```
2. Change proxy url in package.json file
```sh
 "proxy": "https://ai-art-server.onrender.com"
```
Or
```sh
"proxy":"http://localhost:5000"
```
