/* eslint-disable no-undef */
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#FB3951",
        secondary: "#0059D0",
      },
      fontFamily:{
        inter: ['"Inter"','sans-serif'],
        bebas: ['"Bebas Neue"','sans-serif'],
        poppins: ['"Poppins"','sans-serif'],
        simonetta:['Simonetta', 'cursive'],
        crimson:['Crimson Text','serif'],
        roboto:['Roboto Condensed', 'sans-serif'],
      },
      gridTemplateColumns:{
        density:'repeat(auto-fit, minmax(100px, 1fr))'
      }

    },
  },
  plugins: [require("daisyui")],
  daisyui: {
    themes: ["light", "dark"],
  },
};