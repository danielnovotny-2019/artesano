import { createBrowserRouter } from "react-router-dom";
import HomeLayout from "../layout/HomeLayout";
import Error from "../pages/Error/Error";
import Home from "../pages/Home/Home";
import Generate from "../pages/Generate/Generate";
import Gallery from "../pages/Gallery/Gallery";
import ContactUs from "../pages/ContactUs/ContactUs";
import Cart from "../pages/Cart/Cart";
import Payment from "../pages/Payment/Payment";
import Orders from "../pages/Orders/Orders";
import PromptDetails from "../pages/PromptDetails/PromptDetails";

const router = createBrowserRouter([
  {
    path: "/",
    element: <HomeLayout />,
    errorElement: <Error />,
    children: [
      {
        path: "/",
        element: <Home />,
      },
      {
        path: "generate",
        element: <Generate />,
      },
      {
        path: "gallery",
        element: <Gallery />,
      },
      {
        path: "gallery/prompt-details/:id",
        element: <PromptDetails />,
      },
      {
        path: "contact",
        element: <ContactUs />,
      },
      {
        path: "cart",
        element: <Cart />,
      },
      {
        path: "payment",
        element: <Payment />,
      },
      {
        path: "orders",
        element: <Orders />,
      },
    ],
  },
  /*  {
    path: "/",
    element: <NoFooter />,
    errorElement: <Error />,
    children: [
      {
        path: "generate",
        element: <Generate />,
      },
      {
        path: "about",
        element: <AboutMe />,
      },
      {
        path: "contact",
        element: <ContactUs />,
      },
      {
        path: "cart",
        element: <Cart />,
      },
      {
        path: "payment",
        element: <Payment />,
      },
      {
        path: "orders",
        element: <Orders />,
      },
    ],
  }, */
]);

export default router;
