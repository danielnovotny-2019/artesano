// Define the actions
const UPDATE_FIELD = "UPDATE_FIELD" as string;
const UPDATE_All = "UPDATE_All" as string;
const UPDATE_SIZE_PRICE = "UPDATE_SIZE" as string;
const UPDATE_MARTIAL = "UPDATE_MARTIAL" as string;
const UPDATE_QUANTITY = "UPDATE_QUANTITY" as string;
const DELETE_ITEM = "DELETE_ITEM" as string;

export { UPDATE_FIELD, UPDATE_All ,UPDATE_SIZE_PRICE,UPDATE_QUANTITY, UPDATE_MARTIAL, DELETE_ITEM  };
