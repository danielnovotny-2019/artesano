import { Outlet } from "react-router-dom";
import Header from "../shared/Header/Header";
import useStartTop from "../hooks/useStartTop";
const NoFooter = () => {
  useStartTop()
 
  return (
    <div className="w-full h-full overflow-hidden">
    {/* heder is fixed so need to down the content. now giving the space of */}

    <div className="w-full h-16"></div>
      <Header />
     
     <Outlet />
    </div>
  );
};

export default NoFooter;
