// import { Swiper, SwiperSlide } from 'swiper/react'
import { Link } from 'react-router-dom'
import galleryImage1 from '../../assets/gallery/gallery-1.png'
import galleryImage2 from '../../assets/gallery/gallery-2.png'
import galleryImage3 from '../../assets/gallery/gallery-3.png'
import galleryImage4 from '../../assets/gallery/gallery-4.png'
import galleryImage5 from '../../assets/gallery/gallery-5.png'
import galleryImage6 from '../../assets/gallery/gallery-6.png'
import galleryImage7 from '../../assets/gallery/gallery-7.png'
import galleryImage8 from '../../assets/gallery/gallery-8.png'
import './galleryContainer.css'

const GalleryContainer = () => {
  return (
    <>
      <section className=" initial-scale md:transform md:scale-75">
        <div className="gallery-grid-container">
          <div className=" gallery-image-container gallery-img1-container">
            <Link state={{
              promptPageImage:galleryImage1
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage1} alt="Image 1" className="image1" />

            </Link>
          </div>

          <div className="gallery-image-container gallery-img2-container">
            <Link state={{
              promptPageImage:galleryImage2
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage2} alt="Image 2" className="image2" />

              
            </Link>
          </div>
   
          <div className="gallery-image-container gallery-img3-container">
            <Link state={{
              promptPageImage:galleryImage3
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage3} alt="Image 3" className="image3" />

            </Link>
          </div>

          <div className="gallery-image-container gallery-img4-container">
            <Link state={{
              promptPageImage:galleryImage4
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage4} alt="Image 4" className="image4" />

            </Link>
          </div>

          <div className="gallery-image-container gallery-img5-container">
            <Link state={{
              promptPageImage:galleryImage5
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage5} alt="Image 5" className="image5" />

            </Link>
          </div>

          <div className="gallery-image-container gallery-img6-container">
            <Link state={{
              promptPageImage:galleryImage6
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage6} alt="Image 6" className="image6" />

            </Link>
          </div>

          <div className="gallery-image-container gallery-img7-container">
            <Link state={{
              promptPageImage:galleryImage7
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage7} alt="Image 7" className="image7" />

            </Link>
          </div>
          <div className="gallery-image-container gallery-img8-container">
            <Link state={{
              promptPageImage:galleryImage8
            }} to={'prompt-details/details'} className="relative group overflow-hidden w-full h-full">
              <img src={galleryImage8} alt="Image 7" className="image7" />

            </Link>
          </div>
        {/* */}
        </div>
       
       
      </section>
    </>
  );
};

export default GalleryContainer;
