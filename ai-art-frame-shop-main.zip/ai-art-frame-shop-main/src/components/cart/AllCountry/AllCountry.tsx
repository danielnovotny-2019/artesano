/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from "react";
import { FieldValues, UseFormRegister } from "react-hook-form";

const AllCountry = ({
  register,
}: {
  register: UseFormRegister<FieldValues>;
}) => {
  const [countryList, setCountryList] = useState<any[]>([]);

  useEffect(() => {
    const fetchCountry = async () => {
      const response = await fetch("https://restcountries.com/v3.1/all");
      const data = await response.json();
      setCountryList(data);
    };
    fetchCountry();
  }, []);
  // console.log(selectedCountry);
  return (
    <>
      <select
        {...register("country", {
          required: {
            value: true,
            message: "*please select a country",
          },
        })}
        
        className="bg-white text-black text-2xl font-medium leading-tight focus:outline-none focus:bg-white max-w-[80%]"
      >
        <option value="" className="">
          Select you country
        </option>
        {countryList &&
          countryList.map((country) => (
            <option key={country.name.common} value={country.name.common}>
              {country.name.common}
            </option>
          ))}
      </select>
    </>
  );
};

export default AllCountry;
