/* eslint-disable @typescript-eslint/ban-types */
import { FC, useState } from "react";
import { Listbox } from "@headlessui/react";
import { CheckIcon } from "@heroicons/react/20/solid";
import arrowDown from "../../../assets/arrow-down.svg";
interface MaterialOptionsProps {
  options: string[];
  handleOptionChange: Function;
  optionName: string;
  id: string;
}

const MaterialOptions: FC<MaterialOptionsProps> = ({
  options,
  handleOptionChange,
  optionName,
  id,
}) => {
  const [selectedOption, setSelectedOption] = useState(options[0]);
  const handleChange = (option: string) => {
    handleOptionChange(option);
    setSelectedOption(option);
  };
  return (
    <>
      <Listbox
        name={`${id}-${optionName}`}
        value={selectedOption}
        onChange={handleChange}
      >
        <Listbox.Button className="flex items-center gap-4 justify-start ">
          <p className="text-xl md:text-[26px] font-inter text-black font-medium w-fit">
            {selectedOption}
          </p>{" "}
          <div className="md:w-7 w-4">
            <img src={arrowDown} alt="" className="md:w-7 w-4" />
          </div>
        </Listbox.Button>
        <Listbox.Options
          className={`absolute invisible opacity-0 duration-300 group-hover:visible group-hover:opacity-100 top-[calc(100%+10px)] left-0 w-full bg-white rounded-md shadow-md z-10 min-w-[156px] p-3 flex flex-col gap-2 border`}
        >
          {options.map((option) => (
            <Listbox.Option
              id={`${id}-${optionName}-${option}`}
              value={option}
              className={`text-base my-1 font-medium text-blackPrimary cursor-pointer ui-active:bg-blue-500 ui-active:text-white ui-not-active:bg-white ui-not-active:text-black`}
            >
              <CheckIcon className="hidden ui-selected:block" />
              {option}
            </Listbox.Option>
          ))}
        </Listbox.Options>
      </Listbox>
      {/* <div className="absolute invisible opacity-0 duration-300 group-hover:visible group-hover:opacity-100 top-[calc(100%+10px)] left-0 w-full bg-white rounded-md shadow-md z-10 min-w-[156px] p-2 flex flex-col gap-2 border">
      {options.map((option) => (
        <div
          key={`${id}-${option}-${optionName}`}
          className="p-2 flex items-center justify-between gap-3"
        >
          <label
            className="text-sm font-medium text-blackPrimary cursor-pointer"
            htmlFor={`${id}-${optionName}-${option}`}
          >
            {option}
          </label>
          <input
            type="radio"
            className="radio border-black"
            id={`${id}-${optionName}-${option}`}
            value={option}
            name={optionName}
            onChange={() => handleOptionChange(option)}
          />
        </div>
      ))}
    </div> */}
    </>
  );
};

interface SizeOptionsProps extends MaterialOptionsProps {
  defaultSize: string;
}

const SizeOptions: FC<SizeOptionsProps> = ({
  options,
  handleOptionChange,
  optionName,
  id,
  defaultSize,
}) => {
  console.log("size options", { defaultSize });
  const [selectedOption, setSelectedOption] = useState(defaultSize);
  const handleChange = (option: string) => {
    handleOptionChange(option);
    setSelectedOption(option);
  };
  return (
    <>
      <Listbox
        name={`${id}-${optionName}`}
        value={selectedOption}
        onChange={handleChange}
      >
        <Listbox.Button className="flex items-center gap-4 justify-start ">
          <p className="text-xl md:text-[26px] font-inter text-black font-medium w-fit">
            {defaultSize}
          </p>{" "}
          <div className="md:w-7 w-4">
            <img src={arrowDown} alt="" className="md:w-7 w-4" />
          </div>
        </Listbox.Button>
        <Listbox.Options
          className={`absolute invisible opacity-0 duration-300 group-hover:visible group-hover:opacity-100 top-[calc(100%+10px)] left-0 w-full bg-white rounded-md shadow-md z-10 min-w-[156px] p-2 flex flex-col gap-2 border`}
        >
          {options.map((option) => (
            <Listbox.Option
              id={`${id}-${optionName}-${option}`}
              value={option}
              className={`text-sm font-medium text-blackPrimary cursor-pointer ui-active:bg-blue-500 ui-active:text-white ui-not-active:bg-white ui-not-active:text-black`}
            >
              <CheckIcon className="hidden ui-selected:block" />
              {option}
            </Listbox.Option>
          ))}
        </Listbox.Options>
      </Listbox>
      {/* <div className="absolute invisible opacity-0 duration-300 group-hover:visible group-hover:opacity-100 top-[calc(100%+10px)] left-0 w-full bg-white rounded-md shadow-md z-10 min-w-[156px] p-2 flex flex-col gap-2 border">
      {options.map((option) => (
        <div
          key={`${id}-${option}-${optionName}`}
          className="p-2 flex items-center justify-between gap-3"
        >
          <label
            className="text-sm font-medium text-blackPrimary cursor-pointer"
            htmlFor={`${id}-${optionName}-${option}`}
          >
            {option}
          </label>
          <input
            type="radio"
            className="radio border-black"
            id={`${id}-${optionName}-${option}`}
            value={option}
            name={optionName}
            onChange={() => handleOptionChange(option)}
          />
        </div>
      ))}
    </div> */}
    </>
  );
};

export { MaterialOptions, SizeOptions };
