/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import InputField from "../../../shared/InputField/InputField";
import AllCountry from "../AllCountry/AllCountry";
import { useForm } from "react-hook-form";
import PaymentProviders from "../PaymentMethod/PaymentProviders/PaymentProviders";
import { ErrorMessage } from "@hookform/error-message";
import Swal from "sweetalert2";

import {
  CardImage,
  CardTypeDB,
  OrderType,
  PriceType,
  UserType,
} from "../../../types/types";
import { FC } from "react";
import useNewOrder from "../../../hooks/useNewOrder";
import { useNavigate } from "react-router-dom";

interface BillingFormProps {
  cartsData: CardTypeDB[];
  error: string;
  price: PriceType;
}

const BillingForm: FC<BillingFormProps> = ({ cartsData, error, price }) => {
  const {
    orderUserIsError,
    orderUserMutate,
    orderUserIsLoading,
    orderUserSaveRes,
  } = useNewOrder();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (data: any) => {
    // !if card is empty redirect to generate page
    if (cartsData.length === 0) {
      Swal.fire({
        icon: "error",
        title: "Your cart is empty",
        text: "You will be redirected to Generate page",
        showConfirmButton: false,
        timer: 3500,
      });

      setTimeout(async () => {
        // const response = await axiosInstance.post("/payment", orderUserSaveRes?.newOrder);
        // console.log(response.data)
        navigate("/generate", {
          state: {
            orderData: orderUserSaveRes?.newOrder,
          },
        });
      }, 3800);

      return;
    }

    const cardImagesArray: CardImage[] = [];
    const cardIds: string[] = [];

    cartsData.forEach((cartData) => {
      
      cardIds.push(cartData.id);
      cartData.cardImages.forEach((cardImage) => {
        cardImagesArray.push(cardImage);
      });
    });

    const uniqueId = localStorage.getItem("uniqueId") || "";
    // ! user data
    const userData: UserType = {
      name: data.name,
      surname: data.surname,
      email: data.email,
      company: data.company,
      additionalNotes: data.message,
      uniqueId: uniqueId,
      address: {
        city: data.city,
        country: data.country,
        streetNumber: data.streetNumber,
        zipCode: data.zipCode,
      },
    };
    // ! order data
    const orderData: OrderType = {
      paymentMethod: data.paymentMethod,
      deliveryStatus: "PROCESSING",
      orderedImages: cardImagesArray,
      cardIds: cardIds,
      orderStatus: "PADDING",
      paymentStatus: "UNPAID",
      uniqueId: uniqueId,
      totalPrice: price,
    };
    // ! send data to server
    orderUserMutate({
      orderData: orderData,
      userData: userData,
    });
    // mutate(data);
    // console.log({ orderData });
  };
  // console.log({ orderUserSaveRes });

  const navigate = useNavigate();

  // show confirm alert and redirect to payment page
  if (orderUserSaveRes?.success) {
    Swal.fire({
      icon: "success",
      title: "Your order and billing information has been saved successfully",
      text: "You will be redirected to payment page",
      showConfirmButton: false,
      timer: 3500,
    });

    // ! redirect to payment page after 3.8s
    setTimeout(async () => {
      // const response = await axiosInstance.post("/payment", orderUserSaveRes?.newOrder);
      // console.log(response.data)
      navigate("/payment", {
        state: {
          orderData: orderUserSaveRes?.newOrder,
        },
      });
    }, 3800);
  }

  return (
    <>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="grid grid-cols-1 md:grid-cols-2 my-16 md:my-32 gap-24 initial-scale md:transform md:scale-75"
      >
        <div className="space-y-12">
          <div className="grid md:grid-cols-2 gap-11">
            <InputField
              register={register}
              label="name"
              placeholder="your name"
              type="text"
              required
              name="name"
              errors={errors}
            />
            <InputField
              register={register}
              label="surname"
              placeholder="your surname"
              type="text"
              required
              name="surname"
              errors={errors}
            />
          </div>
          <InputField
            register={register}
            label="email"
            placeholder="email"
            type="email"
            required
            name="email"
            errors={errors}
          />

          <InputField
            register={register}
            label="company (optional)"
            placeholder="company"
            type="text"
            required={false}
            name="company"
            errors={errors}
          />

          {/* country */}
          <div className=" w-full  focus:outline-none py-4 px-8  border-[3px] border-black flex items-center justify-center">
            <AllCountry register={register} />
          </div>
          <div className="text-red-700">
            <ErrorMessage errors={errors} name="country" />
          </div>
          {/* country */}
          <div className="grid md:grid-cols-2 gap-11">
            <InputField
              register={register}
              label="zip code"
              placeholder="your zip code"
              type="text"
              required
              name="zipCode"
              errors={errors}
            />
            <InputField
              register={register}
              label="city"
              placeholder="where do you live"
              type="text"
              required
              name="city"
              errors={errors}
            />
          </div>
          <InputField
            register={register}
            label="street number"
            placeholder="street num"
            type="text"
            required
            name="streetNumber"
            errors={errors}
          />

          <div className="">
            <label
              htmlFor="message"
              className="text-2xl md:text-[35px] font-medium"
            >
              Additional notes (optional)
            </label>
            <textarea
              rows={5}
              {...register("message", {
                required: {
                  value: false,
                  message: "",
                },
              })}
              id="message"
              className="w-full block border-b-2 border-black border-l-0 border-t-0 focus:outline-none text-2xl py-4"
              placeholder="what do you want to tell us ?"
            />
            <div className="text-red-700">
              <ErrorMessage errors={errors} name="message" />
            </div>
          </div>
        </div>
        <div>
          <h1 className="text-4xl font-medium  text-black mb-11">
            Payment Method
          </h1>
          <PaymentProviders errors={errors} register={register} />
          <div className="mt-32 space-y-14">
            <div className="flex gap-8">
              <input
                type="checkbox"
                name="paypal"
                id="paypal"
                className="w-7 h-7 border-black border-b-[3px]"
              />
              <div className="flex-1 ">
                <p className="text-2xl font-light text-black/80">
                  Lorem ipsum is placeholder text commonly used in the graphic,
                  print, and publishing industries for previewing layouts and
                  visual mockups.
                </p>
              </div>
            </div>
            <div className="flex gap-8">
              <input
                type="checkbox"
                name="paypal"
                id="paypal"
                className="w-7 h-7 border-black border-b-[3px]"
              />
              <div className="flex-1 ">
                <p className="text-2xl font-light text-black/80">
                  Lorem ipsum is placeholder text commonly used in the graphic,
                  print, and publishing industries for previewing layouts and
                  visual mockups.
                </p>
              </div>
            </div>

            <button
              type="submit"
              className={`w-full py-4 px-8  text-white text-xl bg-black`}
            >
              {orderUserIsLoading ? (
                <>
                  <span className="animate-ping  inline-flex h-4 w-4 mr-4 rounded-full bg-sky-400 opacity-75"></span>
                  Processing...
                </>
              ) : (
                "Order Now"
              )}
            </button>
            {orderUserIsError && (
              <p className="text-red-700">
                There is an error on server to save your data and order{" "}
              </p>
            )}
            {error && <p className="text-red-700">{error}</p>}
          </div>
        </div>
      </form>
    </>
  );
};

export default BillingForm;
