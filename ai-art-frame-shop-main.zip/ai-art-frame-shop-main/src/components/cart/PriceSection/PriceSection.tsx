import { Link } from "react-router-dom";
import { CheckAllFieldsType, PriceType } from "../../../types/types";
import { useEffect } from "react";
const PriceSection = ({
  price,
  error,
  setError,
  checkAllFields,
}: {
  price: PriceType;
  error: string;
  checkAllFields: CheckAllFieldsType[];
  setError: React.Dispatch<React.SetStateAction<string>>;
}) => {
  console.log(error);
  
  useEffect(() => {
    if (checkAllFields.some((field) => !field.imageCardId)) {
      setError("please select all fields");
    } else {
      setError("");
    }
    
  }, [checkAllFields, setError]);
  return (
    <section className="py-9 md:mx-8 initial-scale md:transform md:scale-75">
      <div className="overflow-x-auto my-12">
        <table className="table">
          <tbody>
            {/* row 2 */}
            <tr className="border-y-2 border-black/50">
              <td className="text-2xl py-11 font-inter text-black/70  whitespace-nowrap px-0 w-fit ">
                shipping fee:
              </td>
              <td className="text-[26px] py-11 font-inter text-black font-medium px-0 w-full pl-10 md:pl-24">
                {price.shippingFee}€
              </td>
            </tr>
            {/* row 3 */}
            <tr>
              <td className="text-2xl py-11 font-inter text-black/70  whitespace-nowrap px-0 w-fit">
                sub-total :
              </td>
              <td className="text-[26px] py-11 font-inter text-black font-medium px-0 w-full pl-10 md:pl-24 flex items-center justify-between">
                {price.allImagesPrice &&
                  price.allImagesPrice + price.shippingFee}€
                {/* if any field is not selected then show error message */}

                {checkAllFields.some((field) => {
                  const check =
                    !field.imageCardId || !field.material || !field.size;
                  return check;
                }) && (
                  <h1 className="text-center text-2xl text-red-500 font-medium">
                    *please select all fields
                  </h1>
                )}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="flex gap-8 justify-center items-center">
        <Link
          to="/generate"
          className="border-[3px]  border-black/50 px-8 py-4 font-poppins text-xl "
        >
          + add another image
        </Link>
      </div>
    </section>
  );
};

export default PriceSection;
