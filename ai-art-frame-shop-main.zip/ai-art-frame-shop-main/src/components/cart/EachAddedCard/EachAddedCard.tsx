/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/ban-types */
import React, { useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { BannerSectionProps, Material, SizePrice } from "../../../types/types";
import { MaterialOptions, SizeOptions } from "../Options/Options";
import { useState } from "react";
import { Autoplay, Pagination } from "swiper/modules";
import ImageCardModal from "../ImageCardModal/ImageCardModal";
import { useCard } from "../../../Provider/CardProvider";
import { TrashIcon } from "@heroicons/react/20/solid";

import {
  UPDATE_MARTIAL,
  UPDATE_QUANTITY,
  UPDATE_SIZE_PRICE,
} from "../../../constant/constant";
import useDeleteSingleCard from "../../../hooks/useDeleteSingleCard";
import Swal from "sweetalert2";

const materials: Material[] = [
  {
    material: "Regular Paper, 130g",
    sizePrice: [
      {
        size: "300 x 300 mm",
        price: 6,
      },
      {
        size: "400 x 400 mm",
        price: 12,
      },
      {
        size: "500 x 500 mm",
        price: 14,
      },
      {
        size: "1000 x 1000 mm",
        price: 19,
      },
    ],
  },
  {
    material: "High Gloss Premium Photo Paper, 240g",
    sizePrice: [
      {
        size: "300 x 300 mm",
        price: 9,
      },
      {
        size: "400 x 400 mm",
        price: 19,
      },
      {
        size: "500 x 500 mm",
        price: 24,
      },
      {
        size: "1000 x 1000 mm",
        price: 39,
      },
    ],
  },
  {
    material: "Acryl Glass (10mm thichkness)",
    sizePrice: [
      {
        size: "400 x 400 mm",
        price: 49,
      },
      {
        size: "500 x 500 mm",
        price: 59,
      },
      {
        size: "1000 x 1000 mm",
        price: 99,
      },
    ],
  },
  {
    material: "Premium Polycanvas on 45mm Stretcher Frame",
    sizePrice: [
      {
        size: "400 x 400 mm",
        price: 59,
      },
      {
        size: "500 x 500 mm",
        price: 69,
      },
      {
        size: "1000 x 1000 mm",
        price: 89,
      },
    ],
  },
];

const EachAddedCard: React.FC<BannerSectionProps> = ({
  cartImage,
  index,
  variants,
  cartId,
  setCheckAllFields,
}) => {
  const deleteSingleCard = useDeleteSingleCard();
  const [material, setMaterial] = useState(cartImage.material || "");
  const [sizesPrices, setSizesPrices] = useState<SizePrice[]>([]);
  const [sizePrice, setSizePrice] = useState<SizePrice | undefined>({
    price: cartImage.price || 0,
    size: cartImage.size || "",
    subTotal: cartImage.subTotal || cartImage.price || 0,
  });
  const [numberOfImage, setNumberOfImage] = useState<number>(
    cartImage.numberOfImage || 1
  );
  // card
  const { handleFieldChange } = useCard();

  const [modal, setModal] = useState(false);

  const handleMaterialChange = (option: string) => {
    // console.log(option);
    const selectedMaterial = materials.find(
      (material) => material.material === option
    );
    setSizePrice(undefined);
    if (selectedMaterial) {
      setSizesPrices(selectedMaterial?.sizePrice);
    }

    // update material in card
    handleFieldChange(UPDATE_MARTIAL, {
      cartId,
      cartImage,
      material: option,
    });

    setMaterial(option);
    // update material in card
    handleFieldChange(UPDATE_MARTIAL, { cartId, cartImage, material: option });
  };

  const handleSizesPricesChange = (option: string) => {
    const selectedSizePrice = sizesPrices.find(
      (sizePrice) => sizePrice.size === option
    );

    if (selectedSizePrice) {
      setSizePrice(() => ({
        ...selectedSizePrice,
        subTotal: selectedSizePrice.price * numberOfImage,
      }));

      // update size in card
      handleFieldChange(UPDATE_SIZE_PRICE, {
        cartId,
        cartImage,
        selectedSizePrice: {
          ...selectedSizePrice,
          subTotal: selectedSizePrice.price * numberOfImage,
        },
      });
    }
  };

  const handleQuantityChange = (operator: string) => {
    // console.log(option);

    // increment
    if (operator === "+") {
      setNumberOfImage((prev) => {
        handleFieldChange(UPDATE_QUANTITY, {
          cartId,
          cartImage,
          numberOfImage: prev + 1,
        });
        // update price in card
        handleFieldChange(UPDATE_SIZE_PRICE, {
          cartId,
          cartImage,
          selectedSizePrice: {
            ...sizePrice,
            subTotal: sizePrice?.price && sizePrice?.price * (prev + 1),
          },
        });
        return prev + 1;
      });
    }
    // decrement
    if (operator === "-") {
      setNumberOfImage((prev) => {
        handleFieldChange(UPDATE_QUANTITY, {
          cartId,
          cartImage,
          numberOfImage: prev - 1,
        });

        // update price in card
        handleFieldChange(UPDATE_SIZE_PRICE, {
          cartId,
          cartImage,
          selectedSizePrice: {
            ...sizePrice,
            subTotal: sizePrice?.price && sizePrice?.price * (prev - 1),
          },
        });

        return prev - 1;
      });
    }
  };
  const handleDeleteImage = async () => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    });

    if (result.isConfirmed) {
      Swal.fire({
        icon: "success",
        title: "Deleted!",
        text: "Your file has been deleted.",
        showConfirmButton: false,
        timer: 2000,
      });
      await deleteSingleCard(cartId, cartImage.id as string);
    }

  };

  const pagination = {
    clickable: true,
    renderBullet: function (_index: number, className: string) {
      return `<span class=' ${className} '></span>`;
    },
  };

  useEffect(() => {
    setCheckAllFields((prev) => {
      const isPreviouslySelected = prev.find(
        (checkAllField) => checkAllField.imageCardId === cartImage.id
      );
      if (isPreviouslySelected) {
        return prev.map((checkAllField) => {
          if (checkAllField.imageCardId === cartImage.id) {
            return {
              ...checkAllField,
              material,
              size: sizePrice?.size,
            };
          }
          return checkAllField;
        });
      }
      return [
        ...prev,
        {
          imageCardId: cartImage.id,
          material,
          size: sizePrice?.size,
        },
      ];
    });
  }, [material, sizePrice?.size, cartImage.id]);

  // console.log("each card", cartImage.numberOfImage );
  return (
    <>
      <section className="flex items-center justify-between flex-col md:flex-row gap-16 my-9 md:mx-8 initial-scale md:transform md:scale-75">
        <div className={`w-4/12 grid gap-1   grid-cols-1`}>
          <img
            src={cartImage.imagesUrl}
            alt=""
            className="w-full"
            key={index}
          />
        </div>

        <div className="flex-1">
          {/* title */}
          <div className="flex items-end gap-8">
            <button
              type="button"
              onClick={handleDeleteImage}
              className="w-10 h-10 text-2xl font-inter border border-black rounded-[10px] flex items-center justify-center "
            >
              {/* //Todo  add event listener to delete selected image */}
              <TrashIcon className="w-6 h-6 fill-black" />
            </button>
            <div className="flex-1">
              <p className="text-[28px] font-medium font-poppins mb-2">
                poster for “it is a poster for cd black sun...”
              </p>
            </div>
          </div>

          {/* info */}
          <form className=" my-8">
            <div className="space-y-5">
              {/* row */}
              <div className="flex items-center justify-start ">
                <div className="w-4/12">
                  <p className="text-xl md:text-2xl font-inter text-black/70  md:whitespace-nowrap px-0">
                    material:
                  </p>
                </div>
                <div className="relative group  md:px-8 flex-1">
                  {/* <div className="flex items-center gap-4 justify-start ">
                    <p className="text-xl md:text-[26px] font-inter text-black font-medium w-fit">
                      {material ? material : "poster material"}
                    </p>
                    <div className="md:w-7 w-4">
                      <img src={arrowDown} alt="" className="md:w-7 w-4" />
                    </div>
                  </div> */}
                  <MaterialOptions
                    optionName={`material-${cartImage.id}`}
                    id={cartId}
                    handleOptionChange={handleMaterialChange}
                    options={materials.map((material) => material.material)}
                  />
                </div>
              </div>

              {/* row */}
              <div className="flex items-center justify-start ">
                <div className="w-4/12">
                  <p className="text-xl md:text-2xl font-inter text-black/70  md:whitespace-nowrap px-0">
                    format:
                  </p>
                </div>
                <div className="relative group  md:px-8 flex-1">
                  <SizeOptions
                    optionName={`format-${cartImage.id}`}
                    id={cartId}
                    handleOptionChange={handleSizesPricesChange}
                    options={sizesPrices.map((sizePrice) => sizePrice.size)}
                    defaultSize={
                      sizePrice?.size ? sizePrice.size : "poster size"
                    }
                  />
                </div>
              </div>
              {/* row */}
              <div className="flex items-center justify-start ">
                <div className="w-4/12">
                  <p className="text-xl md:text-2xl font-inter text-black/70  md:whitespace-nowrap px-0">
                    generation model:
                  </p>
                </div>
                <div className="relative group  md:px-8 flex-1">
                  <div className="flex items-center gap-4 justify-start ">
                    <p className="text-xl md:text-[26px] font-inter text-black font-medium w-fit">
                      open ai dalle-2
                    </p>
                  </div>
                </div>
              </div>
              {/* row */}
              <div className="flex items-center justify-start ">
                <div className="w-4/12">
                  <p className="text-xl md:text-2xl font-inter text-black/70  md:whitespace-nowrap px-0">
                    delivery period:
                  </p>
                </div>
                <div className="relative group  md:px-8 flex-1">
                  <div className="flex items-center gap-4 justify-start ">
                    <p className="text-xl md:text-[26px] font-inter text-black font-medium w-fit">
                      2-4 days
                    </p>
                  </div>
                </div>
              </div>
              {/* row */}
              <div className="flex items-center justify-start ">
                <div className="w-4/12">
                  <p className="text-xl md:text-2xl font-inter text-black/70  md:whitespace-nowrap px-0">
                    Price:
                  </p>
                </div>
                <div className="relative group  md:px-8 flex-1">
                  <div className="flex items-center gap-4 justify-start ">
                    <p className="text-xl md:text-[26px] font-inter text-black font-medium w-fit">
                      {sizePrice?.price
                        ? `${
                            sizePrice?.price * numberOfImage
                          } €`
                        : "N/A"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </form>

          <div className="flex gap-8 items-center">
            <div className="flex items-center gap-2 border-2 border-black rounded-full text-black">
              <button
                onClick={() => {
                  if (numberOfImage > 1) {
                    handleQuantityChange("-");
                  }
                }}
                className="px-8 py-4 text-2xl flex items-center justify-center"
              >
                -
              </button>
              <p className="text-2xl  font-inter text-black">{numberOfImage}</p>
              <button
                onClick={() => {
                  handleQuantityChange("+");
                }}
                className="px-8 py-4 text-2xl flex items-center justify-center"
              >
                +
              </button>
            </div>
            <button
              onClick={() => setModal(true)}
              className="border-[3px]  border-black px-8 py-4 text-white bg-black font-poppins text-xl"
            >
              + add variants
            </button>
          </div>

          <div className="mt-4">
            {/* error message */}
            <p className="text-red-500 text-sm">
              {!material && "please select a material"}
            </p>
            <p className="text-red-500 text-sm">
              {!sizePrice?.size && "please select a Paper size"}
            </p>
          </div>
        </div>
      </section>
      {/*==========================================================
                      modal start
============================================================== */}
      <div
        className={`bg-white border-2 fixed w-[95%] md:w-10/12 lg:w-4/12 h-fit left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 p-2 md:p-4 z-30 rounded-lg shadow-xl  transform duration-500 ${
          modal
            ? "scale-100 opacity-100 visible"
            : "scale-0 opacity-0 invisible"
        }`}
      >
        {/* close button */}
        <button
          onClick={() => setModal(false)}
          className="flex items-center justify-center w-10 h-10  text-2xl absolute  -top-3 -right-3 bg-slate-100  rounded-full border-2 "
        >
          X
        </button>
        {/* close button */}

        <>
          {variants && (
            <>
              {/* desktop */}
              <div className=" grid-cols-1 md:grid-cols-2 gap-4  hidden md:grid">
                {variants?.map((imageUrl, index: number) => (
                  <ImageCardModal imageUrl={imageUrl} key={index} />
                ))}
              </div>

              {/* mobile */}
              <div className=" my-6 md:hidden">
                <>
                  <Swiper
                    pagination={pagination}
                    modules={[Pagination, Autoplay]}
                    autoplay={{
                      delay: 1500,
                      disableOnInteraction: false,
                    }}
                    className=""
                  >
                    {variants?.map((imageUrl, index: number) => (
                      <SwiperSlide key={index}>
                        {" "}
                        <ImageCardModal imageUrl={imageUrl} />{" "}
                      </SwiperSlide>
                    ))}
                  </Swiper>
                </>
              </div>
            </>
          )}
        </>
      </div>

      {/*==========================================================
                       modal end
============================================================== */}
    </>
  );
};

export default EachAddedCard;
