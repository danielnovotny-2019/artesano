/* eslint-disable @typescript-eslint/no-explicit-any */
import { Dispatch, SetStateAction } from "react";
import { CardImage, CheckAllFieldsType } from "../../../types/types";
import EachAddedCard from "../EachAddedCard/EachAddedCard";

const BannerSection = ({
  cardImages,
  variants,
  cartId,
  setCheckAllFields,

}: {
  cardImages: CardImage[];
  cartId: string;
  variants: string[];
  setCheckAllFields: Dispatch<SetStateAction<CheckAllFieldsType[]>>;
}) => {
  return (
    <>
      {cardImages.map((cardImage, index: number, arr) => (
        <EachAddedCard
          key={cardImage.id}
          cartId={cartId}
          index={index}
          variants={variants}
          cartImage={cardImage}
          cardImages={arr}
          setCheckAllFields={setCheckAllFields}
        />
      ))}
    </>
  );
};

export default BannerSection;
