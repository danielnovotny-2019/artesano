/* eslint-disable @typescript-eslint/no-unused-vars */
import useQueryCards from "../../../hooks/useQueryCards";
import axiosInstance from "../../../utility/axiosInstace";
import generateUniqueID from "../../../utility/uniqueId";

const ImageCardModal = ({ imageUrl }: { imageUrl: string }) => {
  const { cartsRefetch } = useQueryCards();

  const handleAddToCart = async (): Promise<void> => {
    let uniqueId = localStorage.getItem("uniqueId");
    if (!uniqueId) {
      localStorage.setItem("uniqueId", generateUniqueID());
      uniqueId = localStorage.getItem("uniqueId");
    }
    const request = await axiosInstance.post("/cart", {
      imageUrl,
      generationModel: "open ai dalle-2",
      deliveryPeriod: "2-4 days",
      uniqueId,
    });

    console.log(request.data)
    cartsRefetch()
  }
  return (
    <div className="relative group overflow-hidden">
      <img src={imageUrl} alt="" className=" w-full" />

      {/* overlay */}
      <div className="absolute w-full h-full left-0 top-0 bg-[#0000004D] opacity-0 invisible group-hover:visible group-hover:opacity-100 duration-300"></div>
      {/* add to card button */}
      <button onClick={handleAddToCart} className="z-10 rounded-full bg-white text-black font-medium text-lg duration-300 py-2 px-6 absolute -bottom-full  group-hover:bottom-4 left-2 ">
        Add to card
      </button>
    </div>
  );
};

export default ImageCardModal;
