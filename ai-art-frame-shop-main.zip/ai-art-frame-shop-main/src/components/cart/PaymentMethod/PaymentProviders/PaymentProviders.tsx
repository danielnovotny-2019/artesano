import { ErrorMessage } from "@hookform/error-message";
import papal from "../../../../assets/PayPal_.svg";
import klarna from "../../../../assets/klarna-svgrepo-com.svg";
import stripe from "../../../../assets/stripe-svgrepo-com.svg";
import { FieldErrors, FieldValues, UseFormRegister } from "react-hook-form";

const PaymentProviders = ({
  register,
  errors,
}: {
  register: UseFormRegister<FieldValues>;
  errors: FieldErrors<FieldValues>;
}) => {
  return (
    <> <div className="w-full border-black border-[3px]">
      <div className="border-black border-b-[3px] py-7 px-11 flex items-center justify-between">
        <div className="flex items-center gap-3 text-2xl font-bold">
          <input
            type="radio"
            {...register("paymentMethod", {
              required: {
                value: true,
                message: "*please select a payment method",
              },
            })}
            id="paypal"
            value={'paypal'}
            className="w-7 h-7 border-black border-b-[3px]"
          />
          <label htmlFor="paypal">Paypal</label>
        </div>
        <img src={papal} alt="" className="max-w-[80px]" />
      </div>

      <div className="border-black border-b-[3px] py-3 px-11 flex items-center justify-between">
        <div className="flex items-center gap-3 text-2xl font-bold">
          <input
            type="radio"
            {...register("paymentMethod", {
              required: {
                value: true,
                message: "*please select a payment method",
              },
            })}
            id="stripe"
            value={'stripe'}
            className="w-7 h-7 border-black border-b-[3px]"
          />
          <label htmlFor="stripe">Stripe</label>
        </div>
        <img src={stripe} alt="" className="max-w-[80px]" />
      </div>

      <div className="py-3 px-11 flex items-center justify-between">
        <div className="flex items-center gap-3 text-2xl font-bold">
          <input
            type="radio"
            {...register("paymentMethod", {
              required: {
                value: true,
                message: "*please select a payment method",
              },
            })}
            id="klarna"
            value={'klarna'}
            className="w-7 h-7 border-black border-b-[3px]"
          />
          <label htmlFor="klarna">Klarna</label>
        </div>
        <img src={klarna} alt="" className="max-w-[80px]" />
      </div>

      
    </div>
    <div className="text-red-700"><ErrorMessage errors={errors} name="paymentMethod" /></div>
    </>
  );
};

export default PaymentProviders;
