const PaymentMethod = () => {
  return (
    <div>
      <h1 className="text-4xl font-medium  text-black mb-11">Payment Method</h1>
      <div className="mt-32 space-y-14">
        <div className="flex gap-8">
          <input
            type="checkbox"
            name="paypal"
            id="paypal"
            className="w-7 h-7 border-black border-b-[3px]"
          />
          <div className="flex-1 ">
            <p className="text-2xl font-light text-black/80">
              Lorem ipsum is placeholder text commonly used in the graphic,
              print, and publishing industries for previewing layouts and visual
              mockups.
            </p>
          </div>
        </div>
        <div className="flex gap-8">
          <input
            type="checkbox"
            name="paypal"
            id="paypal"
            className="w-7 h-7 border-black border-b-[3px]"
          />
          <div className="flex-1 ">
            <p className="text-2xl font-light text-black/80">
              Lorem ipsum is placeholder text commonly used in the graphic,
              print, and publishing industries for previewing layouts and visual
              mockups.
            </p>
          </div>
        </div>

        <button className="w-full py-4 px-8 bg-black text-white text-xl">
          Order Now
        </button>
      </div>
    </div>
  );
};

export default PaymentMethod;
