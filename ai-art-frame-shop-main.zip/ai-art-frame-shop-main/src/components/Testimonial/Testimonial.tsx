import testimonial1 from "../../assets/AboutMe/testmonial-1.png";
const StarIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="19"
      height="19"
      viewBox="0 0 19 19"
      fill="none"
    >
      <path
        d="M10.5021 2.68483L11.8483 5.37727C12.0319 5.75207 12.5214 6.11157 12.9344 6.18041L15.3745 6.5858C16.9349 6.84587 17.302 7.97792 16.1776 9.09467L14.2807 10.9916C13.9594 11.3129 13.7835 11.9324 13.8829 12.3761L14.426 14.7243C14.8543 16.583 13.8676 17.302 12.2231 16.3306L9.93605 14.9767C9.523 14.732 8.84224 14.732 8.42155 14.9767L6.13451 16.3306C4.49763 17.302 3.50326 16.5754 3.9316 14.7243L4.47468 12.3761C4.57412 11.9324 4.39819 11.3129 4.07693 10.9916L2.17999 9.09467C1.06324 7.97792 1.42274 6.84587 2.98313 6.5858L5.42315 6.18041C5.82855 6.11157 6.31808 5.75207 6.50166 5.37727L7.84788 2.68483C8.58218 1.22387 9.77542 1.22387 10.5021 2.68483Z"
        fill="#FB3951"
        stroke="#FB3951"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
const Testimonial = () => {
  return (
    <div className="sm:max-w-sm md:max-w-md w-full rounded-3xl p-6 space-y-6  backdrop-blur-sm bg-[#ACAEAF]/40 text-black hover:scale-105 scale-100 transform duration-300 ">
      <div className="">
        <div className="flex items-center gap-2 mb-2">
          <StarIcon />
          <StarIcon />
          <StarIcon />
          <StarIcon />
          <StarIcon />
        </div>
        <p className="italic text-black font-inter">
          “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod temporLorem ipsum dolor sit amet”
        </p>
      </div>
      <div className="">
        <div className="flex items-center gap-4 justify-start">
          <div className="w-10 h-10 rounded-full overflow-hidden">
            <img
              src={testimonial1}
              alt=""
              className="w-full h-full object-cover"
            />
          </div>
          <h3 className="text-2xl text-black font-bebas">Kovács Dávid</h3>
        </div>
        <p className="font-inter">art delivered to Hungary, budapest</p>
      </div>
    </div>
  );
};

export default Testimonial;
