/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { PayPalButtons } from "@paypal/react-paypal-js";
import axiosInstance from "../../utility/axiosInstace";

const PaypalPayment = () => {
  const createOrder = async (data:any) => {
    // Order is created on the server and the order id is returned
console.log(data)
    const response = await axiosInstance.post("/payment-paypal-init", {
      cart: [
        {
          sku: "YOUR_PRODUCT_STOCK_KEEPING_UNIT",
          quantity: "YOUR_PRODUCT_QUANTITY",
        },
      ],
    });
    // console.log(response.data);
    return response.data.id;
  };

  const onApprove = async (data: any) => {
    // Order is captured on the server and the response is returned to the browser
    const response = await axiosInstance.post("/payment-capture-paypal-order", {
      orderID: data.orderID,
    });
    0;
    // console.log(response.data);
    return await response.data;
  };
  // console.log( window?.paypal?.Buttons)
  return (
    <div>
      {
        <PayPalButtons
          createOrder={(data, _actions) => createOrder(data)}
          onApprove={(data, _actions) => onApprove(data)}
        />
      }
    </div>
  );
};

export default PaypalPayment;
