import { useState } from "react";

const AccordionItem = ({title,description}:{title:string;description:string;}) => {
  const [toggleAccordion, setToggleAccordion] = useState<boolean>(false);

  return (
    <>
      <div className="collapse collapse-plus bg-[#D9D9D9] p-3 md:p-6 rounded-none mb-8 initial-scale md:transform md:scale-75">
        <input
          onChange={() => {}}
          onClick={() => setToggleAccordion(!toggleAccordion)}
          checked={toggleAccordion}
          type="radio"
          name={title}
        />
        <div className="collapse-title text-start md:text-5xl text-2xl font-bebas cursor-pointer">
          {title}
        </div>
        <div className="collapse-content">
          <p>
           {description}
          </p>
        </div>
      </div>
    </>
  );
};

export default AccordionItem;
