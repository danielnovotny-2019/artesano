import AccordionItem from "./AccordionItem/AccordionItem";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Autoplay } from "swiper/modules";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

const accordionContent = [
  {
    id: "accordionId-1",
    title:
      "How can I create a personalized artwork using AI and customize it for printing?",
    description:
      "Start by providing a creative prompt or a brief description of your idea. The sophisticated Midjourney and DALL-E AI models will then transform your input into a unique piece of art that captures your vision. After receiving the AI-generated artwork, explore the selection and choose your favorite. Proceed to select your preferred printing method, and find the ideal frame for your artwork. Utilize the configurator to preview how your chosen artwork, printing method, and frame will harmonize with various interior settings, ensuring they align seamlessly with your creative concepts.",
  },
  {
    id: "accordionId-2",
    title: "Where does my artwork originate, and how is it crafted?",
    description:
      "Your artwork is meticulously crafted through the capabilities of both the Midjourney and DALL-E AI models. These cutting-edge AI technologies are adept at crafting unique pieces of art based on your prompts and concepts. The best part? You won't need a subscription to either of these services. Our platform seamlessly integrates multiple AI systems to provide you with a multitude of options and inspiration.",
  },
  {
    id: "accordionId-3",
    title:
      "How do I go about placing an order and receiving my customized artwork?",
    description:
      "Should the preview align with your vision, simply add the artwork to your cart. Choose one out of many materials and formats. Complete the ordering process by selecting your preferred payment method.",
  },
  {
    id: "accordionId-4",
    title: "Can I choose different printing methods and frames for my artwork?",
    description:
      "Absolutely. After selecting your favorite AI-generated artwork, you can explore various printing methods to best suit your artistic vision. Furthermore, you have the option to choose a frame that enhances your artwork's presentation and complements your personal style. ",
  },
  {
    id: "accordionId-5",
    title: "What styles of art are available through this AI-based service?",
    description: `Our AI-powered art creation spans a wide range of styles, from abstract designs to landscapes, portraits, and more. The AI's versatility ensures you can explore various artistic expressions and find the style that resonates with your individual taste.`,
  },
  {
    id: "accordionId-6",
    title: "How can I explore the different art styles available?",
    description: `To explore the available art styles, simply input your creative prompt or idea. The Midjourney and DALL-E AI models will then generate art that aligns with the style and essence you're looking for. This enables you to discover and embrace the artistic expressions that uniquely reflect you.`,
  },
  {
    id: "accordionId-7",
    title:
      "What information can you provide about shipping costs and duration?    ",
    description: `Shipping costs are subject to variation based on your location and selected shipping method. We offer shipping to all European countries. The delivery duration typically ranges from 3 to 7 days, contingent on your location and the shipping option chosen during checkout. Rest assured, our commitment lies in providing efficient and dependable shipping, ensuring your unique artwork arrives at your doorstep promptly.`,
  },
];

const Accordion = () => {
  const pagination = {
    clickable: true,
    renderBullet: function (_index: number, className: string) {
      return `<span class=' ${className} '></span>`;
    },
  };
  return (
    <>
      <section className=" hidden md:block md:space-y-8 ">
        {accordionContent.map((accordion) => (
          <AccordionItem
            key={accordion.id}
            description={accordion.description}
            title={accordion.title}
          />
        ))}
      </section>

      <div className=" md:hidden">
        <>
          <Swiper
            pagination={pagination}
            modules={[Pagination, Autoplay]}
            /*  autoplay={{
              delay: 500,
              disableOnInteraction: false,
            }} */
            className=""
          >
            {accordionContent.map((accordion) => (
              <SwiperSlide key={accordion.id}>
                <AccordionItem
                  title={accordion.title}
                  description={accordion.description}
                />
              </SwiperSlide>
            ))}
          </Swiper>
        </>
      </div>
    </>
  );
};

export default Accordion;
