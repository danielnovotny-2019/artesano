import enhanceIcon from "../../../../assets/enhance.svg";
import chooseWhat from "../../../../assets/chooseWhat.svg";
import wallet from "../../../../assets/wallet.svg";
const Stapes = () => {
  return (
    <div className="relative space-y-9 md:space-y-0 initial-scale md:transform md:scale-75 ">
      {/* first left align */}
      <div className="w-[calc(100%-1rem)] mx-auto md:mx-0 md:w-1/2  relative ">
        <div className="relative p-2 md:p-[10px]  w-10/12 md:mx-0 mx-auto ">
          <div
            style={{
              boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",
            }}
            className=" p-3 md:p-6 border border-slate-500 rounded-lg  bg-gradient-to-tr from-[#FBFAFC] via-[#ffffff] to-[#F7F3F5]"
          >
            <h4 className=" text-[19px] md:text-start text-center md:text-5xl md:mb-4 font-bebas uppercase">
              Choose motive and write prompt (enter)
            </h4>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) Choose the motive for your artwork
            </p>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) Write a creative prompt or decribe your idea briefly (example
              prompts and results shall be indicated here)
            </p>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) Our super efficient AI converts your prompt into a unique piece
              of art exactly reflecting
            </p>
          </div>
          <div className="w-3/12 h-full absolute border-y-[2.4px] md:border-y-[6px] border-r-[2.4px] md:border-r-[6px] border-[#353434] top-0 right-0 rounded-e-2xl"></div>
          <div className="w-3/12 h-full absolute md:border-y-[6px] border-y-[2.4px] md:border-l-[6px] border-l-[2.4px] border-[#353434] top-0 left-0 rounded-s-2xl md:hidden"></div>
        </div>
        {/* dash  */}
        <div className="w-2/12  border border-dashed border-black absolute top-1/2 -translate-y-1/2 right-0 md:block hidden"></div>
        {/* middle circle icon */}
        <div className="w-8 h-8 md:w-32 md:h-32 rounded-full bg-slate-600 flex items-center justify-center absolute md:top-1/2 md:-translate-y-1/2 md:-right-16 right-6 -top-2">
          <img src={enhanceIcon} alt="" className="w-full h-full" />
        </div>
        {/* first element down line */}
        <div className="absolute h-1/2 w-1 bg-slate-900 left-full top-1/2 -translate-x-1/2 -z-10 md:block hidden"></div>
      </div>

      {/* second right align */}
      <div className="w-[calc(100%-1rem)] mx-auto md:mx-0 md:w-1/2 relative md:ml-auto">
        <div className="relative p-2 md:p-[10px]  w-10/12 mx-auto md:mr-0 md:ml-auto">
          <div
            style={{
              boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",
            }}
            className=" p-3 md:p-6 border border-slate-500 rounded-lg  bg-gradient-to-tr from-[#FBFAFC] via-[#ffffff] to-[#F7F3F5]"
          >
            <h4 className=" text-[19px] md:text-start text-center md:text-5xl md:mb-4 font-bebas uppercase">
              Choose your picture, and afterwards, choose printing method and
              frame by means of the configurator
            </h4>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) Choose your favorite from the AI created artworks
            </p>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) Decide for the preferred printing method and find the perfect
              frame for your artwor
            </p>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) A preview in different interior settings will make sure that
              your choice will perfectly fit your ideas
            </p>
          </div>
          <div className="w-3/12 h-full absolute border-y-[2.4px] md:border-y-[6px] md:border-l-[6px] border-r-[2.4px] md:border-r-0 border-[#353434] top-0 right-0 md:left-0 md:rounded-s-2xl rounded-e-2xl md:rounded-e-none "></div>
          <div className="w-3/12 h-full absolute md:border-y-[6px] border-y-[2.4px] md:border-l-[6px] border-l-[2.4px] border-[#353434] top-0 left-0 rounded-s-2xl md:hidden"></div>
        </div>

        {/* dash  */}
        <div className="w-2/12 border border-dashed border-black absolute top-1/2 -translate-y-1/2 md:left-0 right-0 hidden md:block "></div>
        {/* middle circle icon */}
        <div className="w-8 h-8 md:w-32 md:h-32 rounded-full bg-slate-600 flex items-center justify-center absolute md:top-1/2 md:-translate-y-1/2 md:-left-16 right-6 -top-2">
          <img src={chooseWhat} alt="" className="w-full h-full" />
        </div>
      </div>

      {/* third left align */}
      <div className="w-[calc(100%-1rem)]  mx-auto md:mx-0 md:w-1/2 relative">
        <div className="relative p-2 md:p-[10px]  mx-auto md:mx-0 w-10/12 ">
          <div
            style={{
              boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",
            }}
            className=" p-3 md:p-6 border border-slate-500 rounded-lg  bg-gradient-to-tr from-[#FBFAFC] via-[#ffffff] to-[#F7F3F5]"
          >
            <h4 className=" text-[19px] md:text-start text-center md:text-5xl md:mb-4 font-bebas uppercase">
              Order and receive your artwork
            </h4>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) The preview matches your idea? Then add to cart.
            </p>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) Choose preferred method of payment and complete ordering
              procedure
            </p>
            <p className="text-[9.6px] text-center md:text-start  md:text-2xl">
              -) Lean back and look foward to the delivery of your unique
              artwork directly to your home
            </p>
          </div>
          <div className="w-3/12 h-full absolute border-y-[2.4px] md:border-y-[6px] border-r-[2.4px] md:border-r-[6px] border-[#353434] top-0 right-0 rounded-e-2xl"></div>
          <div className="w-3/12 h-full absolute md:border-y-[6px] border-y-[2.4px] md:border-l-[6px] border-l-[2.4px] border-[#353434] top-0 left-0 rounded-s-2xl md:hidden"></div>
        </div>
        {/* dash  */}
        <div className="w-2/12 border border-dashed border-black absolute top-1/2 -translate-y-1/2 right-0 md:block hidden"></div>
        {/* middle circle icon */}
        <div className="w-8 h-8 md:w-32 md:h-32 rounded-full bg-slate-600 flex items-center justify-center absolute md:top-1/2 md:-translate-y-1/2 md:-right-16 right-6 -top-2">
          <img src={wallet} alt="" className="w-full h-full" />
        </div>

        {/* Last element up line */}
        <div className="absolute h-1/2 w-1 bg-slate-900 left-full top-0 -translate-x-1/2 -z-10 md:block hidden"></div>
      </div>

      {/* middle line fo common container */}
      <div
        className="absolute h-2/3 md:h-1/2 w-0 md:w-1 md:bg-slate-900 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 -z-50 
      
      border border-dashed border-black md:border-none
      "
      ></div>
    </div>
  );
};

export default Stapes;
