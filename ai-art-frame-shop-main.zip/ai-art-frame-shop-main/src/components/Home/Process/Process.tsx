import SectionTitle from "../../../shared/SectionTitle/SectionTitle";
import Stapes from "./Stapes/Stapes";
import stepsBg from "../../../assets/stepsBg.png";

const Process = () => {
  return (
    <section className="space-y-6 relative ">
      <div className="container mx-auto md:px-8 px-4 my-4 md:my-10 py-4 ">
        <SectionTitle
          title="THE PROCESS"
          description="create the artwork of your dreams in an intuitive process saving effort and time"
        />
        <Stapes />
        <div className="hidden items-center justify-center gap-5 md:gap-12 md:flex mt-8 initial-scale md:transform md:scale-75">
          <button className="md:py-4 py-2 md:px-10 px-6 border-2 border-black bg-black text-white duration-500 hover:bg-white hover:text-black font-semibold font-poppins rounded-full ">
            See more examples
          </button>
          <button className="md:py-4 py-2 md:px-10 px-6 border-2 border-black   duration-500 hover:bg-black hover:text-white font-semibold font-poppins rounded-full ">
            Design now
          </button>
        </div>

        {/* button for mobile */}
        <div className="md:hidden flex items-center justify-center gap-4  mt-8 initial-scale md:transform md:scale-75">
          <button className="py-[6.5px] px-[18px] text-white bg-black text-[7px] font-semibold">
            See more examples
          </button>
          <button className="py-[6.5px] px-[18px] text-black bg-white border-[1.2px] border-black text-[7px] font-semibold">
            Design now
          </button>
        </div>
      </div>
      {/* background image */}
      <div className="w-full h-full  absolute -z-10 top-0 left-0 ">
        <img src={stepsBg} alt="" className="w-full h-full object-cover" />
      </div>
    </section>
  );
};

export default Process;
