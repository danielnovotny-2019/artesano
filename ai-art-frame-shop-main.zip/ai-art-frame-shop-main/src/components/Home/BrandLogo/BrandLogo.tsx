import paypal from "../../../assets/BrandLogo/PayPal.svg";
import sripe from "../../../assets/BrandLogo/Stripe_.svg";
import openai from "../../../assets/BrandLogo/openai_.svg";
import midjourney from "../../../assets/BrandLogo/midjourney.png";
import k from "../../../assets/BrandLogo/Vector (1).svg";

const BrandLogo = () => {
  return (
    <div className="  py-3 md:py-5 border-y-2 border-black ">
      <div className="flex items-center justify-center gap-5 md:gap-16 initial-scale md:transform md:scale-75 ">
        <p className="text-xs md:text-[32px] font-medium text-black/70 font-roboto">
          partnered with:{" "}
        </p>
        <img src={paypal} alt="" className="md:w-[133.73px]" />{" "}
        <img src={sripe} alt="" className=" md:w-[111.651px]" />{" "}
        <img src={openai} alt="" className="md:w-[64.715px]" />
        <img src={midjourney} alt="" className="w-8 md:w-[98.69px]" />
        <img src={k} alt="" className="md:w-[69.449px]" />
      </div>
    </div>
  );
};

export default BrandLogo;
