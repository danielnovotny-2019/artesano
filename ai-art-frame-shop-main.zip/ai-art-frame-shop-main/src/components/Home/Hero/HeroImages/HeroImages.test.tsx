import image1 from "../../../../assets/Rectangle 22701.png";
import image2 from "../../../../assets/Rectangle 22699.png";
import image3 from "../../../../assets/Rectangle 22704.png";
import image4 from "../../../../assets/Rectangle 22700.png";
import image5 from "../../../../assets/Rectangle 22703.png";
import image6 from "../../../../assets/Rectangle 22702.png";
import image7 from "../../../../assets/Rectangle 22705.png";

const HeroImages = () => {
  return (
    <section className="my-8">
      <div className="flex items-stretch flex-wrap w-full gap-4 flex-col md:flex-row  ">
        {/* first column 2 images */}
        <div className="grid grid-cols-1 gap-4 md:grid-rows-2 ">
          <div className=" rounded-3xl relative group overflow-hidden w-full h-full ">
            <img src={image1} alt="" className="block h-full w-full" />
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
             <div className=" absolute left-0 max-h-40 bottom-0 bg-black p-4 overflow-auto w-8/12 mb-8 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 ">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
              molestiae provident esse dolores assumenda natus et nobis
              laboriosam? Placeat totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.
             </div>
            </div>
          </div>
          <div className=" rounded-3xl relative group overflow-hidden w-full h-full ">
            <img src={image7} alt="" className="block h-full w-full" />
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
             <div className=" absolute left-0 max-h-40 bottom-0 bg-black p-4 overflow-auto w-8/12 mb-8 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 ">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
              molestiae provident esse dolores assumenda natus et nobis
              laboriosam? Placeat totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.
             </div>
            </div>
          </div>
        </div>

        {/* second column 4 */}
        <div className="flex justify-evenly flex-wrap gap-4 flex-1 flex-col md:flex-row">
          <div className=" rounded-3xl relative group overflow-hidden w-full h-full md:w-[calc(65%-16px)] md:h-fit ">
            <img src={image2} alt="" className="w-full h-full" />
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
             <div className=" absolute left-0 max-h-40 bottom-0 bg-black p-4 overflow-auto w-8/12 mb-8 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 ">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
              molestiae provident esse dolores assumenda natus et nobis
              laboriosam? Placeat totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.
             </div>
            </div>
          </div>
          <div className=" rounded-3xl relative group overflow-hidden w-full h-full md:w-[calc(35%-16px)] md:h-fit ">
            <img src={image3} alt="" className="w-full h-full" />
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
             <div className=" absolute left-0 max-h-40 bottom-0 bg-black p-4 overflow-auto w-8/12 mb-8 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 ">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
              molestiae provident esse dolores assumenda natus et nobis
              laboriosam? Placeat totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.
             </div>
            </div>
          </div>
          <div className=" rounded-3xl relative group overflow-hidden w-full h-full md:w-[calc(35%-16px)] md:h-fit ">
            <img src={image4} alt="" className=" w-full h-full" />
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
             <div className=" absolute left-0 max-h-40 bottom-0 bg-black p-4 overflow-auto w-8/12 mb-8 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 ">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
              molestiae provident esse dolores assumenda natus et nobis
              laboriosam? Placeat totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.
             </div>
            </div>
          </div>
          <div className=" rounded-3xl relative group overflow-hidden w-full  md:w-[calc(63%-16px)] md:h-fit">
            <img src={image5} alt="" className="w-full h-full" />
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
             <div className=" absolute left-0 max-h-40 bottom-0 bg-black p-4 overflow-auto w-8/12 mb-8 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 ">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
              molestiae provident esse dolores assumenda natus et nobis
              laboriosam? Placeat totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.
             </div>
            </div>
          </div>
        </div>

        {/* third column 1 */}
        <div className="grid grid-cols-1 ">
          <div className=" rounded-3xl relative group overflow-hidden w-full h-full">
            <img src={image6} alt="" className="w-full h-full" />
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
             <div className=" absolute left-0 max-h-40 bottom-0 bg-black p-4 overflow-auto w-8/12 mb-8 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 ">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
              molestiae provident esse dolores assumenda natus et nobis
              laboriosam? Placeat totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.totam cumque labore consectetur quisquam, ut
              quidem culpa expedita cum atque.
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroImages;
