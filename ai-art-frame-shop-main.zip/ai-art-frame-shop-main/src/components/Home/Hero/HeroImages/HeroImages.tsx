import { Swiper, SwiperSlide } from "swiper/react";
import image1 from "../../../../assets/Rectangle 22701.png";
import image2 from "../../../../assets/Rectangle 22699.png";
import image3 from "../../../../assets/Rectangle 22704.png";
import image4 from "../../../../assets/Rectangle 22700.png";
import image5 from "../../../../assets/Rectangle 22703.png";
import image6 from "../../../../assets/Rectangle 22702.png";
import image7 from "../../../../assets/Rectangle 22705.png";
import mobileHero1 from "../../../../assets/mobileHero-1.png";
import mobileHero2 from "../../../../assets/mobileHero-2.png";
import mobileHero3 from "../../../../assets/mobileHero-3.png";
import mobileHero4 from "../../../../assets/mobileHero-4.png";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "./gridStyle.css";

import { Pagination, Autoplay } from "swiper/modules";
const HeroImages = () => {
  const pagination = {
    clickable: true,
    renderBullet: function (_index: number, className: string) {
      return `<span class=' ${className} '></span>`;
    },
  };
  // '<span class=" ">' + (index ) + '</span>'
  return (
    <section className="my-8 initial-scale md:transform md:scale-75">
      <div className="my-grid-container md:!grid !hidden">
        <div className=" image-container  image1-container">
          <div className="relative group overflow-hidden w-full h-full">
            <img src={image1} alt="Image 1" className="image1" />

            {/* prompt */}
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
              <div className=" absolute left-0 max-h-[70%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-4 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                <p className="font-semibold text-lg text-[#FC9259]">Prompt: </p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
                molestiae provident esse dolores assumenda natus et nobis
                laboriosam? Placeat totam cumque labore consectetur quisquam, ut
                quidem culpa expedita cum atque.totam cumque labore consectetur
                quisquam, ut quidem culpa expedita cum atque.
              </div>
            </div>
            {/* prompt */}
          </div>
        </div>

        <div className="image-container  image2-container">
          <div className="relative group overflow-hidden w-full h-full">
            <img src={image2} alt="Image 2" className="image2" />

            {/* prompt */}
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
              <div className=" absolute left-0 max-h-[70%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-4 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                <p className="font-semibold text-lg text-[#FC9259]">Prompt: </p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
                molestiae provident esse dolores assumenda natus et nobis
                laboriosam? Placeat totam cumque labore consectetur quisquam, ut
                quidem culpa expedita cum atque.totam cumque labore consectetur
                quisquam, ut quidem culpa expedita cum atque.
              </div>
            </div>
            {/* prompt */}
          </div>
        </div>

        <div className="image-container  image3-container">
          <div className="relative group overflow-hidden w-full h-full">
            <img src={image3} alt="Image 3" className="image3" />

            {/* prompt */}
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
              <div className=" absolute left-0 max-h-[70%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-4 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                <p className="font-semibold text-lg text-[#FC9259]">Prompt: </p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
                molestiae provident esse dolores assumenda natus et nobis
                laboriosam? Placeat totam cumque labore consectetur quisquam, ut
                quidem culpa expedita cum atque.totam cumque labore consectetur
                quisquam, ut quidem culpa expedita cum atque.
              </div>
            </div>
            {/* prompt */}
          </div>
        </div>

        <div className="image-container  image4-container">
          <div className="relative group overflow-hidden w-full h-full">
            <img src={image4} alt="Image 4" className="image4" />

            {/* prompt */}
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
              <div className=" absolute left-0 max-h-[70%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-4 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                <p className="font-semibold text-lg text-[#FC9259]">Prompt: </p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
                molestiae provident esse dolores assumenda natus et nobis
                laboriosam? Placeat totam cumque labore consectetur quisquam, ut
                quidem culpa expedita cum atque.totam cumque labore consectetur
                quisquam, ut quidem culpa expedita cum atque.
              </div>
            </div>
            {/* prompt */}
          </div>
        </div>

        <div className="image-container  image5-container">
          <div className="relative group overflow-hidden w-full h-full">
            <img src={image5} alt="Image 5" className="image5" />

            {/* prompt */}
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
              <div className=" absolute left-0 max-h-[70%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-4 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                <p className="font-semibold text-lg text-[#FC9259]">Prompt: </p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
                molestiae provident esse dolores assumenda natus et nobis
                laboriosam? Placeat totam cumque labore consectetur quisquam, ut
                quidem culpa expedita cum atque.totam cumque labore consectetur
                quisquam, ut quidem culpa expedita cum atque.
              </div>
            </div>
            {/* prompt */}
          </div>
        </div>

        <div className="image-container  image6-container">
          <div className="relative group overflow-hidden w-full h-full">
            <img src={image6} alt="Image 6" className="image6" />

            {/* prompt */}
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
              <div className=" absolute left-0 max-h-[70%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-4 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                <p className="font-semibold text-lg text-[#FC9259]">Prompt: </p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
                molestiae provident esse dolores assumenda natus et nobis
                laboriosam? Placeat totam cumque labore consectetur quisquam, ut
                quidem culpa expedita cum atque.totam cumque labore consectetur
                quisquam, ut quidem culpa expedita cum atque.
              </div>
            </div>
            {/* prompt */}
          </div>
        </div>

        <div className="image-container  image7-container">
          <div className="relative group overflow-hidden w-full h-full">
            <img src={image7} alt="Image 7" className="image7" />

            {/* prompt */}
            <div className="absolute left-0 bg-[#0000004D] p-4 rounded-3xl text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
              <div className=" absolute left-0 max-h-[70%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-4 ml-4 rounded-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                <p className="font-semibold text-lg text-[#FC9259]">Prompt: </p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora
                molestiae provident esse dolores assumenda natus et nobis
                laboriosam? Placeat totam cumque labore consectetur quisquam, ut
                quidem culpa expedita cum atque.totam cumque labore consectetur
                quisquam, ut quidem culpa expedita cum atque.
              </div>
            </div>
            {/* prompt */}
          </div>
        </div>
      </div>
      {/* mobile start */}
      <div className=" md:hidden">
        <>
          <Swiper
            pagination={pagination}
            modules={[Pagination, Autoplay]}
            /*  autoplay={{
          delay: 500,
          disableOnInteraction: false,
        }} */
            className=""
          >
             <SwiperSlide className="mb-4">
              <div className="relative group overflow-hidden w-full h-full">
                <img src={mobileHero4} alt="Image 2" className="mobileHero4" />

                {/* prompt */}
                {/* <div className="absolute left-0 bg-[#0000004D] p-4  text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
                  <div className=" absolute left-0 max-h-[65%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-10 ml-4 rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                    <p className="font-semibold text-lg text-[#FC9259]">
                      Prompt:{" "}
                    </p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Tempora molestiae provident esse dolores assumenda natus et
                    nobis laboriosam? Placeat totam cumque labore consectetur
                    quisquam, ut quidem culpa expedita cum atque.totam cumque
                    labore consectetur quisquam, ut quidem culpa expedita cum
                    atque.
                  </div>
                </div> */}
                {/* prompt */}
              </div>
            </SwiperSlide>
            <SwiperSlide className="mb-4">
              <div className="relative group overflow-hidden w-full h-full">
                <img src={mobileHero1} alt="Image 2" className="mobileHero1" />

                {/* prompt */}
                {/* <div className="absolute left-0 bg-[#0000004D] p-4  text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
                  <div className=" absolute left-0 max-h-[65%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-10 ml-4 rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                    <p className="font-semibold text-lg text-[#FC9259]">
                      Prompt:{" "}
                    </p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Tempora molestiae provident esse dolores assumenda natus et
                    nobis laboriosam? Placeat totam cumque labore consectetur
                    quisquam, ut quidem culpa expedita cum atque.totam cumque
                    labore consectetur quisquam, ut quidem culpa expedita cum
                    atque.
                  </div>
                </div> */}
                {/* prompt */}
              </div>
            </SwiperSlide>
            <SwiperSlide className="mb-4">
              <div className="relative group overflow-hidden w-full h-full">
                <img src={mobileHero2} alt="Image 2" className="mobileHero2" />

                {/* prompt */}
                {/* <div className="absolute left-0 bg-[#0000004D] p-4  text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
                  <div className=" absolute left-0 max-h-[65%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-10 ml-4 rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                    <p className="font-semibold text-lg text-[#FC9259]">
                      Prompt:{" "}
                    </p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Tempora molestiae provident esse dolores assumenda natus et
                    nobis laboriosam? Placeat totam cumque labore consectetur
                    quisquam, ut quidem culpa expedita cum atque.totam cumque
                    labore consectetur quisquam, ut quidem culpa expedita cum
                    atque.
                  </div>
                </div> */}
                {/* prompt */}
              </div>
            </SwiperSlide>
            <SwiperSlide className="mb-4">
              <div className="relative group overflow-hidden w-full h-full">
                <img src={mobileHero3} alt="Image 2" className="mobileHero3" />

                {/* prompt */}
                {/* <div className="absolute left-0 bg-[#0000004D] p-4  text-white w-full  h-full bottom-0 overflow-auto duration-500 opacity-0 invisible group-hover:opacity-100 group-hover:visible">
                  <div className=" absolute left-0 max-h-[65%] bottom-0 bg-black p-4 overflow-auto w-10/12 mb-10 ml-4 rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible duration-500 font-crimson ">
                    <p className="font-semibold text-lg text-[#FC9259]">
                      Prompt:{" "}
                    </p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Tempora molestiae provident esse dolores assumenda natus et
                    nobis laboriosam? Placeat totam cumque labore consectetur
                    quisquam, ut quidem culpa expedita cum atque.totam cumque
                    labore consectetur quisquam, ut quidem culpa expedita cum
                    atque.
                  </div>
                </div> */}
                {/* prompt */}
              </div>
            </SwiperSlide>
           
          </Swiper>
        </>
      </div>
      {/* mobile end */}
      <p className="hidden md:block my-8 text-center opacity-75 font-crimson text-2xl">
        art created by ai
      </p>
     
    </section>
  );
};

export default HeroImages;
