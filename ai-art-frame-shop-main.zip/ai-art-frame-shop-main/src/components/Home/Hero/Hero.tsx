import HeroImages from "./HeroImages/HeroImages";
import starIcon from "../../../assets/star.svg";
const Hero = () => {
  return (
    <div>
      <div className="w-full">
        <h1 className="text-[32px] md:text-7xl leading-[33px] font-bebas text-center md:text-start text-black initial-scale md:transform md:scale-75">
          Become a real artist and create{" "}
          <span className="block md:inline">your own masterpiece with </span>{" "}
          <span className="block md:inline leading-[33px]">
            <img
              src={starIcon}
              alt=""
              className="inline-block me-2 md:hidden"
            />
            a simple prompt!
            <img src={starIcon} alt="" className="inline-block ml-2 md:w-10" />
          </span>
        </h1>
        <p className=" text-sm md:text-2xl text-gray-700 md:mt-4 mt-2 text-center md:text-start initial-scale md:transform md:scale-75">
          Unleash your creativity with your own prompts and get unique pieces of
          art. For an optimal fine tuning to your interior you can choose from a
          large number of printing methods and frames. Dive into the world of
          arts and add the final touch to your home.
        </p>
      </div>
      <HeroImages />
    </div>
  );
};

export default Hero;
