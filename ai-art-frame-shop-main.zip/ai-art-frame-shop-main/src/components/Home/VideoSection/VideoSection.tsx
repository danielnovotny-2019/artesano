import starIcon from "../../../assets/star-black.svg";
const VideoSection = () => {
  return (
    <section className="relative">
      <div className="relative w-fit initial-scale md:transform md:scale-75">
        <div className="w-full md:w-10/12 lg:w-8/12 flex items-center justify-center flex-col gap-3 md:gap-6 mx-auto my-4 md:my-8  md:p-4 relative">
          <div className=" text-[25.5px] md:text-6xl text-center text-black mx-auto font-bebas uppercase relative">
            ART MADE FOR YOU BY YOU
            <>
              <div className="absolute top-0 -left-12 md:-left-24">
                <img src={starIcon} alt="" className="block w-4 md:w-6" />
                <img
                  src={starIcon}
                  alt=""
                  className="block w-3 md:w-4 ml-6 md:ml-8 mt-1 md:mt-2 lg:my-4"
                />
              </div>
              <div className="absolute top-0 -right-14 md:-right-24">
                <img
                  src={starIcon}
                  alt=""
                  className="block w-4 md:w-6 ml-6 md:ml-8"
                />
                <img
                  src={starIcon}
                  alt=""
                  className="block w-3 md:w-4 mr-9 mt-1 md:mt-2 lg:my-4"
                />
              </div>
            </>
          </div>
          <p className="text-center text-black text-xs md:text-3xl font-light">
            Our AI enables the creation of artworks reflecting your uniqueness -
            something that could not be done - up to now! Learn about your
            advantages!
          </p>
        </div>
      </div>
      <div className="hidden items-center justify-center gap-5 md:gap-12 md:flex initial-scale md:transform md:scale-75">
        <button className="md:py-4 py-2 md:px-10 px-6 border-2 border-black bg-black text-white duration-500 hover:bg-white hover:text-black font-semibold font-poppins rounded-full ">
          Demo
        </button>
        <button className="md:py-4 py-2 md:px-10 px-6 border-2 border-black   duration-500 hover:bg-black hover:text-white font-semibold font-poppins rounded-full ">
          sign up{" "}
        </button>
      </div>

      {/* button for mobile */}
      <div className="md:hidden flex items-center justify-center gap-4">
        <button className="py-[6.5px] px-[18px] text-white bg-black text-[7px] font-semibold">
          Design now
        </button>
        <button className="py-[6.5px] px-[18px] text-black bg-white border-[1.2px] border-black text-[7px] font-semibold">
          Learn more
        </button>
      </div>
      <div className="my-8 md:my-10 w-10/12 mx-auto initial-scale md:transform md:scale-75">
        {/* <iframe width="560" height="315" src="https://www.youtube.com/embed/ah-1WRBLF6o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> */}
        <iframe
          className=" w-full rounded-lg aspect-video"
          src="https://www.youtube.com/embed/ah-1WRBLF6o"
          title="Generate your AI art "
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        ></iframe>
      </div>

      <div className="absolute top-[calc(100%-5.4rem)] md:top-[calc(100%-12rem)] right-0 md:right-12 -z-20 max-w-full">
        <svg
          className="md:hidden"
          xmlns="http://www.w3.org/2000/svg"
          width="260"
          height="236"
          viewBox="0 0 260 236"
          fill="none"
        >
          <path
            d="M205.167 2C247.456 22.1953 304.373 68.2734 193.732 91.024C55.4314 119.462 -42.0327 110.807 22.2174 152.434C86.4675 194.061 164.33 240.634 11.3276 233.215"
            stroke="url(#paint0_linear_604_122)"
            strokeWidth="3"
          />
          <defs>
            <linearGradient
              id="paint0_linear_604_122"
              x1="130"
              y1="2"
              x2="130"
              y2="234"
              gradientUnits="userSpaceOnUse"
            >
              <stop />
              <stop offset="1" stopColor="#A8A8A8" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="801"
          height="763"
          viewBox="0 0 801 763"
          fill="none"
          className="md:block hidden"
        >
          <path
            d="M634.515 2C766.172 68.0699 943.373 218.817 598.917 293.247C168.347 386.284 -135.086 357.968 64.9425 494.153C264.971 630.338 507.379 782.703 31.0393 758.432"
            stroke="url(#paint0_linear_1_46)"
            strokeWidth="3"
          />
          <defs>
            <linearGradient
              id="paint0_linear_1_46"
              x1="400.5"
              y1="2"
              x2="400.5"
              y2="761"
              gradientUnits="userSpaceOnUse"
            >
              <stop />
              <stop offset="1" stopColor="#A8A8A8" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </section>
  );
};

export default VideoSection;
