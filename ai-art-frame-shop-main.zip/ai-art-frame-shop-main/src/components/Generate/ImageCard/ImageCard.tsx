import useQueryCards from "../../../hooks/useQueryCards";
import axiosInstance from "../../../utility/axiosInstace";
import generateUniqueID from "../../../utility/uniqueId";

const ImageCard = ({ imageUrl,variants,isDisabled }: { imageUrl: string,variants?:string[],isDisabled?:boolean }) => {
  const {cartsRefetch} = useQueryCards()
  // when user click on add to cart button this function will be called
  const handleAddToCart = async (): Promise<void> => {
    let uniqueId = localStorage.getItem("uniqueId");
    if (!uniqueId) {
      localStorage.setItem("uniqueId", generateUniqueID());
      uniqueId = localStorage.getItem("uniqueId");
    }
    const request = await axiosInstance.post("/cart", {
      imageUrl,
      generationModel: "open ai dalle-2",
      deliveryPeriod: "2-4 days",
      uniqueId,
      variants
    });
    
    // after adding to cart we need to refetch the cart data
    cartsRefetch()
    console.log(request.data);
  };
  // console.log({variants,imageUrl})
  return (
    <div className="relative group overflow-hidden">
      <img  src={imageUrl} alt="" className=" w-full" />

      {/* overlay */}
      <div className="absolute w-full h-full left-0 top-0 bg-[#0000004D] opacity-0 invisible group-hover:visible group-hover:opacity-100 duration-300"></div>
      {/* add to card button */}
      <button
      disabled={isDisabled}
        onClick={handleAddToCart}
        className="z-10 rounded-full bg-white text-black font-medium text-sm   md:text-2xl duration-300 py-2 px-4 md:py-[18px] md:px-[42px] absolute -bottom-full right-4 md:right-10 group-hover:bottom-10  "
      >
        Add to card
      </button>
    </div>
  );
};

export default ImageCard;
