import { FC } from "react";
import { UseFormRegister } from "react-hook-form";
import { PromptType } from "../../../types/types";
interface OptionsProps {
  options: {
    label: string;
    disabled: boolean;
  }[];
  register: UseFormRegister<PromptType>;
  optionName: "aspectRatio" | "generatorApi";
}

const Options: FC<OptionsProps> = ({ options, register, optionName }) => {

  return (
    <div className="absolute invisible opacity-0 duration-300 group-hover:visible group-hover:opacity-100 top-[calc(100%+10px)] left-0 w-full bg-white rounded-md shadow-md z-10 min-w-[156px] p-2 flex flex-col gap-2 border">
      {options.map((option) => (
        <div
          key={option.label}
          className="p-2 flex items-center justify-between gap-3"
        >
          <label
            className={`text-sm font-medium text-blackPrimary cursor-pointer ${
              option.disabled && "opacity-50"
            }`}
            htmlFor={option.label}
          >
            {option.label}
          </label>
          <input
            type="radio"
            className="radio"
            id={option.label}
            value={option.label}            
            disabled={option.disabled}
            {...register(optionName)}
          />
        </div>
      ))}
    </div>
  );
};

export default Options;
