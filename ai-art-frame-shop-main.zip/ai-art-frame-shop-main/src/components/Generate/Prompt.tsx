/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
// import { useState } from "react";

import Options from "./Options/Options";
import arrowDown from "../../assets/arrow-down.svg";
import { useForm, SubmitHandler } from "react-hook-form";
import { PromptType } from "../../types/types";
import { UseMutateFunction } from "@tanstack/react-query";
import { AxiosResponse } from "axios";
import { useEffect, useState } from "react";

const styleTagsItems = [
  {
    label: "Oil painting",
  },
  {
    label: "Vintage",
  },
  {
    label: "Cyberpunk",
  },
  {
    label: "Picasso",
  },
  {
    label: "Abstract",
  },
  {
    label: "Anime",
  },
];

const Prompt = ({
  mutate,
}: {
  mutate: UseMutateFunction<
    AxiosResponse<any, any>,
    unknown,
    PromptType,
    unknown
  >;
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors: inputErrors },
    watch,
    getValues,
    setValue,
  } = useForm<PromptType>();

  const [styleTags, setStyleTags] = useState<string>();

  const handleSelectStyleTag = (tag: string) => {
    setStyleTags(tag);
  };

  const onSubmit: SubmitHandler<PromptType> = (data) => {
    // console.log(data, inputErrors);
    // console.log({...data,styleTags})
    mutate({...data,styleTags});
  };
  useEffect(() => {
    setValue("generatorApi", "DALLE-2");
  }, []);
  console.log(getValues("generatorApi"));
  return (
    <section className=" space-y-2 md:space-y-6 mb-6 initial-scale md:transform md:scale-75 ">
      <div className="flex items-center justify-between">
        <h2 className="mb-2 md:mb-0 text-base md:text-3xl font-medium text-black  ">
          Text prompt
        </h2>

        {inputErrors && (
          <span className="text-red-500">
            {inputErrors.prompt?.message ||
              inputErrors.aspectRatio?.message ||
              inputErrors.generatorApi?.message}
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="">
          <textarea
            // value={prompt}
            // onChange={handleTextChange}
            {...register("prompt", {
              required: {
                value: true,
                message: "Prompt is required",
              },
            })}
            className="py-2 px-3 md:px-12 border-[1.5px] md:border-2 border-black h-full text-base rounded-full md:text-2xl text-black/80 w-full focus:outline-none resize-none"
            placeholder="tyt black desert storm, in the style of pop art-inspired illustrations, klaus wittmann, artgerm, soviet socialist realism, pierce brosnan, emotionally "
          />
        </div>

        <div className="flex items-center justify-center gap-1 md:gap-4 md:justify-between my-6 ">
          <div className=" flex items-center justify-center gap-1 md:gap-4">
            {/* generated model */}
            <div className="relative group  bg-white text-black py-[6px] px-4 text-[10.5px] md:text-2xl leading-tight border-[1.125px] md:border-2 border-black md:py-[18px] rounded-full flex items-center gap-[2px]  md:gap-4 md:px-10">
              <p className="">{watch("generatorApi")}</p>{" "}
              <img src={arrowDown} alt="" className="md:w-7 w-4" />
              <Options
                optionName={"generatorApi"}
                register={register}
                options={[
                  {
                    label: "DALLE-2 ",
                    disabled: false,
                  },
                  {
                    label: "Midjourney coming soon",
                    disabled: true,
                  },
                  {
                    label: "stable  Defusion coming soon",
                    disabled: true,
                  },
                ]}
              />
            </div>
          </div>
          <button
            type="submit"
            className="border-2 border-black px-4 md:px-[42px] rounded-full text-white bg-black py-[7px] md:py-[18px] md:text-2xl text-[11px] "
          >
            generate
          </button>
        </div>

        {/* ===============
        Style Tag
   ================== */}
        <div className="space-y-4 mt-8">
          <h4 className="text-3xl text-center font-semibold text-[#EC374D]">
            Style Tags
          </h4>
          <div className="w-full bg-black/50 flex items-center justify-center">
            <div className="w-[300px] h-1 bg-[#EC374D] "></div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 md:gap-6 gap-4">
            {styleTagsItems.map((item) => (
              <button
                type="button"
                onClick={() => {
                  if (item.label === styleTags) {
                    handleSelectStyleTag("");
                  } else {
                    handleSelectStyleTag(item.label);
                  }
                }}
                className={`w-full py-6 text-center bg-[#D9D9D9] ${
                  styleTags === item.label
                    ? "bg-[#FC92594D] font-bold text-[#FB3951]"
                    : "font-medium text-black bg-[#D9D9D9]"
                } rounded-xl text-2xl `}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
        {/* ===============
        Style Tag End
   ================== */}
      </form>
    </section>
  );
};

export default Prompt;
