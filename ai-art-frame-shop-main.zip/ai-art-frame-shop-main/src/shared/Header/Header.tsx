import { Link, NavLink } from "react-router-dom";
import { useState } from "react";
import logo from "../../assets/logo.png";
import toggleButton from "../../assets/toggleButton.png";
import closeButton from "../../assets/closeButton.svg";
import navBarLine from "../../assets/navBarLine.svg";
import useQueryCards from "../../hooks/useQueryCards";
import useFetchOrders from "../../hooks/useFetchOrders";

const navItems = [
  {
    name: "Home",
    path: "/",
  },
  {
    name: "Generate",
    path: "/generate",
  },
  {
    name: "Gallery",
    path: "/gallery",
  },

  {
    name: "Contact us",
    path: "/contact",
  },
];
const Header = () => {
  const [toggleNav, setToggleNav] = useState(false);
  const { cartsData } = useQueryCards();
  const { orders } = useFetchOrders();
  const totalImages = cartsData?.reduce(
    (acc, curr) => curr.cardImages.length + acc,
    0
  );

  // console.log(orders)
  return (
    <div className=" w-full fixed top-0 left-0 bg-white z-50  ">
      {" "}
      <div className=" initial-scale md:transform md:scale-75 ">
        <div className="container sm:px-8 px-6 mx-auto ">
          <div className="navbar  rounded-b-lg">
            <div className="navbar-start">
              {/* cart for mobile start */}
              <Link to="/cart" className="mr-4 md:mr-6 md:hidden relative">
                {cartsData && (
                  <div className="absolute -top-1 -right-1 text-xs flex items-center justify-center w-4 h-4 rounded-full border border-black bg-white z-10 ">
                    {totalImages}
                  </div>
                )}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="28"
                  height="28"
                  viewBox="0 0 52 52"
                  fill="none"
                >
                  <path
                    d="M35.2084 48.7499C36.214 48.7499 37.1784 48.3504 37.8895 47.6394C38.6006 46.9283 39 45.9639 39 44.9583C39 43.9526 38.6006 42.9882 37.8895 42.2771C37.1784 41.5661 36.214 41.1666 35.2084 41.1666C34.2028 41.1666 33.2383 41.5661 32.5273 42.2771C31.8162 42.9882 31.4167 43.9526 31.4167 44.9583C31.4167 45.9639 31.8162 46.9283 32.5273 47.6394C33.2383 48.3504 34.2028 48.7499 35.2084 48.7499ZM17.875 48.7499C18.8807 48.7499 19.8451 48.3504 20.5562 47.6394C21.2672 46.9283 21.6667 45.9639 21.6667 44.9583C21.6667 43.9526 21.2672 42.9882 20.5562 42.2771C19.8451 41.5661 18.8807 41.1666 17.875 41.1666C16.8694 41.1666 15.905 41.5661 15.1939 42.2771C14.4829 42.9882 14.0834 43.9526 14.0834 44.9583C14.0834 45.9639 14.4829 46.9283 15.1939 47.6394C15.905 48.3504 16.8694 48.7499 17.875 48.7499ZM10.4867 8.53659L10.0534 13.8449C9.96671 14.8633 10.7684 15.7083 11.7867 15.7083H44.9584C45.8684 15.7083 46.6267 15.0149 46.6917 14.1049C46.9734 10.2699 44.0484 7.14992 40.2134 7.14992H13.585C13.3684 6.19659 12.935 5.28659 12.2634 4.52825C11.18 3.37992 9.66337 2.70825 8.10337 2.70825H4.33337C3.44504 2.70825 2.70837 3.44492 2.70837 4.33325C2.70837 5.22159 3.44504 5.95825 4.33337 5.95825H8.10337C8.77504 5.95825 9.40337 6.23992 9.85837 6.71659C10.3134 7.21492 10.53 7.86492 10.4867 8.53659ZM44.4384 18.9583H11.2017C10.2917 18.9583 9.55504 19.6516 9.46837 20.5399L8.68837 29.9649C8.61399 30.8382 8.72173 31.7174 9.00477 32.5468C9.28781 33.3763 9.73998 34.138 10.3327 34.7836C10.9253 35.4292 11.6456 35.9448 12.4479 36.2976C13.2502 36.6504 14.117 36.8328 14.9934 36.8333H39.0867C42.3367 36.8333 45.1967 34.1683 45.435 30.9183L46.15 20.7999C46.1707 20.5639 46.1416 20.3261 46.0646 20.1021C45.9876 19.878 45.8645 19.6725 45.7032 19.4989C45.5419 19.3254 45.346 19.1876 45.1281 19.0945C44.9103 19.0013 44.6753 18.9549 44.4384 18.9583Z"
                    fill="black"
                  />
                </svg>
              </Link>
              {/* cart for mobile end */}
              <NavLink
                to="/"
                className="ms-2 normal-case text-xl md:flex items-center justify-center gap-1 hidden"
              >
                {/* logo */}
                <img
                  src={logo}
                  alt="logo of AI Art to Frame "
                  className=" w-32 "
                />
              </NavLink>
            </div>
            <div className="navbar-center  md:flex">
              {/* logo mobile start */}
              <NavLink
                to="/"
                className="ms-2 normal-case text-xl flex items-center justify-center gap-1 md:hidden"
              >
                {/* logo */}
                <img
                  src={logo}
                  alt="logo of AI Art to Frame "
                  className=" w-32 "
                />
              </NavLink>
              {/* logo mobile end */}

              <div className="menu menu-horizontal px-1 space-x-1 hidden md:inline-flex">
                {navItems.map((item, index) => (
                  <NavLink
                    key={index}
                    className={({ isActive }) => `duration-300 ${
                      isActive
                        ? " text-primary relative font-bold after:bg-[url('/active.svg')] after:absolute after:w-6 after:h-6 after:bg-center after:bg-no-repeat after:top-8 after:left-1/2 after:-translate-x-1/2 "
                        : "text-headerBody hover:text-primary"
                    }    rounded-md py-[10px] md:px-3 lg:px-6 font-medium text-base 
             `}
                    to={item.path}
                  >
                    {item.name}
                  </NavLink>
                ))}
                {orders?.length > 0 && (
                  <NavLink
                    key={"order-nav-button"}
                    className={({ isActive }) => `duration-300  ${
                      isActive
                        ? " text-primary relative font-bold after:bg-[url('/active.svg')] after:absolute after:w-6 after:h-6 after:bg-center after:bg-no-repeat after:top-8 after:left-1/2 after:-translate-x-1/2 "
                        : "text-headerBody hover:text-primary"
                    }    rounded-md py-[10px] md:px-3 lg:px-6 font-medium text-base 
           `}
                    to={"/orders"}
                  >
                    <div className="relative">
                      <span className="">My Orders</span>

                      <div className="absolute -top-1 -right-4 text-xs flex items-center justify-center w-4 h-4 rounded-full border border-black bg-white z-10 text-black">
                        {orders?.length}
                      </div>
                    </div>
                  </NavLink>
                )}
              </div>
            </div>

            {/* right navigation bars start*/}
            <div className="navbar-end">
              {/* cart */}
              <Link
                to="/cart"
                className="mr-4 md:mr-6 hidden md:inline-block relative"
              >
                {cartsData && (
                  <div className="absolute -top-1 -right-1 text-xs flex items-center justify-center w-4 h-4 rounded-full border border-black bg-white z-10 ">
                    {totalImages}
                  </div>
                )}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="28"
                  height="28"
                  viewBox="0 0 52 52"
                  fill="none"
                >
                  <path
                    d="M35.2084 48.7499C36.214 48.7499 37.1784 48.3504 37.8895 47.6394C38.6006 46.9283 39 45.9639 39 44.9583C39 43.9526 38.6006 42.9882 37.8895 42.2771C37.1784 41.5661 36.214 41.1666 35.2084 41.1666C34.2028 41.1666 33.2383 41.5661 32.5273 42.2771C31.8162 42.9882 31.4167 43.9526 31.4167 44.9583C31.4167 45.9639 31.8162 46.9283 32.5273 47.6394C33.2383 48.3504 34.2028 48.7499 35.2084 48.7499ZM17.875 48.7499C18.8807 48.7499 19.8451 48.3504 20.5562 47.6394C21.2672 46.9283 21.6667 45.9639 21.6667 44.9583C21.6667 43.9526 21.2672 42.9882 20.5562 42.2771C19.8451 41.5661 18.8807 41.1666 17.875 41.1666C16.8694 41.1666 15.905 41.5661 15.1939 42.2771C14.4829 42.9882 14.0834 43.9526 14.0834 44.9583C14.0834 45.9639 14.4829 46.9283 15.1939 47.6394C15.905 48.3504 16.8694 48.7499 17.875 48.7499ZM10.4867 8.53659L10.0534 13.8449C9.96671 14.8633 10.7684 15.7083 11.7867 15.7083H44.9584C45.8684 15.7083 46.6267 15.0149 46.6917 14.1049C46.9734 10.2699 44.0484 7.14992 40.2134 7.14992H13.585C13.3684 6.19659 12.935 5.28659 12.2634 4.52825C11.18 3.37992 9.66337 2.70825 8.10337 2.70825H4.33337C3.44504 2.70825 2.70837 3.44492 2.70837 4.33325C2.70837 5.22159 3.44504 5.95825 4.33337 5.95825H8.10337C8.77504 5.95825 9.40337 6.23992 9.85837 6.71659C10.3134 7.21492 10.53 7.86492 10.4867 8.53659ZM44.4384 18.9583H11.2017C10.2917 18.9583 9.55504 19.6516 9.46837 20.5399L8.68837 29.9649C8.61399 30.8382 8.72173 31.7174 9.00477 32.5468C9.28781 33.3763 9.73998 34.138 10.3327 34.7836C10.9253 35.4292 11.6456 35.9448 12.4479 36.2976C13.2502 36.6504 14.117 36.8328 14.9934 36.8333H39.0867C42.3367 36.8333 45.1967 34.1683 45.435 30.9183L46.15 20.7999C46.1707 20.5639 46.1416 20.3261 46.0646 20.1021C45.9876 19.878 45.8645 19.6725 45.7032 19.4989C45.5419 19.3254 45.346 19.1876 45.1281 19.0945C44.9103 19.0013 44.6753 18.9549 44.4384 18.9583Z"
                    fill="black"
                  />
                </svg>
              </Link>
              <Link
                to={"/generate"}
                className="border md:border-2 border-black py-2   rounded-full hover:bg-black hover:text-white lowercase px-4 md:px-6  text-base duration-500 font-bold hidden md:inline-block "
              >
                generate
              </Link>
              {/* mobile nav start */}
              <div className=" ml-4  md:hidden">
                <button onClick={() => setToggleNav(!toggleNav)} className="">
                  <label className="">
                    {toggleNav ? (
                      <img
                        src={closeButton}
                        alt="toggleButton"
                        className="w-5"
                      />
                    ) : (
                      <img
                        src={toggleButton}
                        alt="toggleButton"
                        className="w-5"
                      />
                    )}
                  </label>
                </button>
                {/* when click on button then it open */}
                <div
                  className={`md:hidden menu absolute bg-base-200 menu-compact dropdown-content mt-5 p-2 shadow  rounded-box w-full h-[calc(100vh-4rem)] -right-8 top-11 z-40 transform transition-all duration-300`}
                  style={{
                    right: toggleNav ? "0px" : "-100%",
                  }}
                >
                  {navItems.map((item, index) => (
                    <NavLink
                      key={index}
                      onClick={() => setToggleNav(false)}
                      className={({ isActive }) => `${
                        isActive
                          ? " relative after:bg-[url('/mobileActive.svg')] after:absolute after:w-7 after:h-7 after:bg-center after:bg-no-repeat after:top-1/2 after:left-0  after:-translate-y-1/2 "
                          : " hover:text-primary "
                      }    rounded-md py-2 px-4  text-4xl font-bebas 
                 inline-block `}
                      to={item.path}
                    >
                      <span className="ml-6">{item.name}</span>
                    </NavLink>
                  ))}
                </div>
              </div>
              {/* mobile nav end */}
            </div>
            {/* right navigation bars end */}
          </div>
        </div>
        <img
          src={navBarLine}
          alt=""
          className="absolute top-full left-1/2 -translate-x-1/2"
        />
      </div>
    </div>
  );
};

export default Header;
