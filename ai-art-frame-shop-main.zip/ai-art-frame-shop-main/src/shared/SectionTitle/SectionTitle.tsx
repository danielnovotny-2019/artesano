import { FC } from "react";
import { SectionTitleProps } from "../../types/types";

import starIcon from "../../assets/star-black.svg";

const SectionTitle: FC<SectionTitleProps> = ({ title, description, star }) => {
  return (
    <div className="w-11/12 md:w-10/12 lg:w-8/12 flex items-center justify-center flex-col gap-6 mx-auto my-4 md:my-8 p-3 md:p-4 relative initial-scale md:transform md:scale-75">
      <h2 className=" text-2xl md:text-6xl text-center text-black  font-bebas uppercase">
        {title}
      </h2>
      <p className="text-center text-black text-xs md:text-3xl font-light">
        {description}
      </p>
      {star && (
        <>
          <div className="absolute top-0 left-0">
            <img src={starIcon} alt="" className="block w-6" />
            <img src={starIcon} alt="" className="block w-4 ml-9 my-2 lg:my-4" />
          </div>
          <div className="absolute top-0 right-0">
            <img src={starIcon} alt="" className="block w-6 ml-8" />
            <img src={starIcon} alt="" className="block w-4 mr-9  my-2 lg:my-4" />
          </div>
        </>
      )}
    </div>
  );
};

export default SectionTitle;
