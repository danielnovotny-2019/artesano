/* eslint-disable @typescript-eslint/no-unused-vars */
import { FC } from "react";
import { InputFieldProps } from "../../types/types";
import { ErrorMessage } from "@hookform/error-message";

const InputField: FC<InputFieldProps> = ({
  label,
  placeholder,
  type,
  classNames,
  register,
  required,
  errors,
  name,
}) => {
  return (
    <div className="">
      <label htmlFor={label} className="text-2xl md:text-[35px] font-medium">
        {label}
      </label>
      <input
        type={type}
        {...register(name, {
          required: {
            value: !!required,
            message: required ? ` ${label} is required` : "",
          },
        })}
        id={label}
        className={`w-full block border-b-2 border-black border-l-0 border-t-0 focus:outline-none text-2xl py-4 ${classNames}`}
        placeholder={placeholder}
      />
      {errors && (
        <>
          <div className="text-red-700">
            <ErrorMessage errors={errors} name={name} />
          </div>
        </>
      )}
    </div>
  );
};

export default InputField;
