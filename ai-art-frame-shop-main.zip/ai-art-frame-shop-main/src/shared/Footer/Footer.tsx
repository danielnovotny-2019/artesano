import logo from "../../assets/logo.png";
import { Link } from "react-router-dom";
import {
  FaFacebookSquare,
  FaTwitter,
  FaVimeoV,
  FaYoutube,
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-[#D9D9D9]  ">
      <div className="container mx-auto footer footer-center px-12 py-6 text-base-content rounded initial-scale md:transform md:scale-75">
        <div className="flex items-center justify-between w-full flex-wrap ">
          <div className="flex flex-wrap gap-8">
            <Link
              to={"/"}
              className="link link-hover text-[#0A142F] font-medium text-sm"
            >
              Home
            </Link>
            <Link
              to={"/generate"}
              className="link link-hover text-[#0A142F] font-medium text-sm"
            >
              Generate
            </Link>
            <Link
              to={"/about"}
              className="link link-hover text-[#0A142F] font-medium text-sm"
            >
              About us
            </Link>
            <Link
              to={"/contact"}
              className="link link-hover text-[#0A142F] font-medium text-sm"
            >
              Contact us
            </Link>
          </div>
          <div className="grid grid-flow-col gap-4">
            <Link to={""} className="p-2 text-3xl block text-black">
              <FaFacebookSquare />
            </Link>
            <Link to={""} className="p-2 text-3xl block text-black">
              <FaTwitter />
            </Link>
            <Link to={""} className="p-2 text-3xl block text-black">
              <FaVimeoV />
            </Link>
            <Link to={""} className="p-2 text-3xl block text-black">
              <FaYoutube />
            </Link>
          </div>
        </div>
      </div>
      <hr className="border-t-[#0A142F]" />
      <div className="container mx-auto footer footer-center  px-12 py-6  text-base-content rounded initial-scale md:transform md:scale-75 ">
        <div className="flex items-center justify-center md:justify-between w-full flex-wrap">
          <p className="text-[#0A142F] font-medium text-sm">
            © {new Date().getFullYear()} Lift Media. All rights reserved.
          </p>
          <div className="">
            {/* logo */}
            <img
              src={logo}
              alt="logo of AI Art to Frame "
              className=" w-32 filter saturate-50"
            />
          </div>
          <div className="grid grid-flow-col gap-4">
            <Link to={""} className="text-[#0A142F] font-medium text-sm">
              Terms of Service
            </Link>
            <Link to={""} className="text-[#0A142F] font-medium text-sm">
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
