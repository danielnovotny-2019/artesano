import { useMutation } from "@tanstack/react-query";
import { PromptType } from "../types/types";
import axiosInstance from "../utility/axiosInstace";
import generateUniqueID from "../utility/uniqueId";

const usePrompt = () => {
  const { data:response, error, isError, isLoading, mutate } = useMutation({
    mutationFn: (prompt: PromptType) => {
      // console.log(prompt);
      // generate unique id for each user
      let uniqueId = localStorage.getItem("uniqueId");
    if (!uniqueId) {
      localStorage.setItem("uniqueId", generateUniqueID());
      uniqueId = localStorage.getItem("uniqueId");
    }
      return axiosInstance.post("/generate", {
        numberOfImage: 4,
        prompt: prompt.prompt,
        sizeOfImage: '256x256',
        generatorApi:prompt.generatorApi,
        uniqueId,
        styleTags:prompt.styleTags
      });
    },
  });
  // console.log('after mutation',response,error)
const data = response?.data
  return { data, error, isError, isLoading, mutate };
};

export default usePrompt;
