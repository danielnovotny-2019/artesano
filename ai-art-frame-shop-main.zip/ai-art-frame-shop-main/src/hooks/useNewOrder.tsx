/* eslint-disable @typescript-eslint/no-unused-vars */
import { useMutation } from "@tanstack/react-query";
import { NewOrderType } from "../types/types";
import axiosInstance from "../utility/axiosInstace";

const useNewOrder = () => {
  const {
    data: response,
    isError,
    isLoading,
    mutate,
    error,
  } = useMutation({
    mutationFn: (newOrder: NewOrderType) => {
      return axiosInstance.post("/order", newOrder);
    },
  });
  const data = response?.data;
  return {
    orderUserSaveRes: data,
    orderUserError: error,
    orderUserIsError: isError,
    orderUserIsLoading: isLoading,
    orderUserMutate: mutate,
  };
};

export default useNewOrder;
