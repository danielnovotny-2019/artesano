import { useQuery } from "@tanstack/react-query";
import axiosInstance from "../utility/axiosInstace";
import { OrderType } from "../types/types";

const useFetchOrders = () => {
  const {
    data: response,
    refetch: ordersRefetch,
    isLoading: ordersIsLoading,
    isError: ordersIsError,
    error: ordersError,
  } = useQuery({
    queryKey: ["orders"],
    queryFn: () => {
      return axiosInstance.get(`/order/${localStorage.getItem("uniqueId")}`);
    },
  });
  const orders = response?.data.orders as OrderType[];
  // console.log(response?.data)
  return {
    orders,
    ordersError,
    ordersRefetch,
    ordersIsError,
    ordersIsLoading,
  };
};

export default useFetchOrders;
