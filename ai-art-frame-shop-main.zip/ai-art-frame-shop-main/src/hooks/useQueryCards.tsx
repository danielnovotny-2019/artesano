import { useQuery } from "@tanstack/react-query";
import axiosInstance from "../utility/axiosInstace";
import { CardTypeDB } from "../types/types";

const useQueryCards = () => {
  const {
    data: response,
    refetch: cartsRefetch,
    isLoading: cartsIsLoading,
    isError: cartsIsError,
    error: cartsError,
  } = useQuery({
    queryKey: ["cards"],
    queryFn: () => {
      const uniqueId = localStorage.getItem("uniqueId");
      return axiosInstance.get(`/cart/${uniqueId}`);
    },
  });
  const data = response?.data?.allCarts as CardTypeDB[];
  return {
    cartsData: data,
    cartsError,
    cartsRefetch,
    cartsIsError,
    cartsIsLoading,
  };
};

export default useQueryCards;
