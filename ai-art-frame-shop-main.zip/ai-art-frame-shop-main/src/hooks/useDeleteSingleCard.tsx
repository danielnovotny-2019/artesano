import axiosInstance from "../utility/axiosInstace";
import useQueryCards from "./useQueryCards";

const useDeleteSingleCard =  () => {
  const { cartsRefetch } = useQueryCards();
  const deleteSingleCard = async (cardId: string, cardImageId: string) => {
    try {
      // console.log(updatedImages)
      const response = await axiosInstance.delete(`/cart-single/${cardId}`, {
        data: {
          cardImageId,
        },
      });
      console.log("response", response);
      cartsRefetch();
    } catch (error) {
      console.log("error", error);
    }
  };
  return deleteSingleCard;
};

export default useDeleteSingleCard;
