// import promptDetails from "../../assets/promptDetails/promptDetails.png";
import starBardaiIcons from "../../assets/icons/star-bardai-icons.png";
import interior from "../../assets/icons/interior.png";
import { useLocation } from "react-router-dom";
const PromptDetails = () => {
  const location = useLocation();

  const { promptPageImage } = location.state;

  if (!promptPageImage)
    return (
      <>
        {" "}
        <h2 className="uppercase text-6xl font-bebas">
          You Do't select any image to show it's details prompt
        </h2>
      </>
    );

  return (
    <div className="container mx-auto md:px-8 px-4 my-4 md:my-10 py-4 ">
      <div className="shadow-2xl shadow-slate-700   rounded-3xl">
        {promptPageImage && (
          <img src={promptPageImage} alt="" className="w-full  rounded-xl" />
        )}
      </div>
      <div className="mt-14 space-y-10">
        <div className="">
          <h2 className="uppercase text-6xl font-bebas">generation prompt :</h2>
          <p className="italic font-light text-3xl font-inter">
            “Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s, when an unknown printer took a galley of type
            and scrambled it to make a type specimen book. It has survived not
            only five centuries, but also the leap into electronic typesetting,
            remaining essentially unchanged. It was popularised in the 1960s
            with the release of Letraset sheets containing Lorem Ipsum passages,
            and more recently with desktop publishing software like Aldus
            PageMaker including versions of Lorem Ipsum.”
          </p>
        </div>
        <div className="">
          <h2 className="uppercase text-6xl font-bebas">generation prompt :</h2>
          <p className="italic font-light text-3xl font-inter">
            “Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s, when an unknown printer took a galley of type
            and scrambled it to make a type specimen book. It has survived not
            only five centuries, but also the leap into electronic typesetting,
            remaining essentially unchanged. It was popularised in the 1960s
            with the release of Letraset sheets containing Lorem Ipsum passages,
            and more recently with desktop publishing software like Aldus
            PageMaker including versions of Lorem Ipsum.”
          </p>
        </div>
        <div className="flex items-center justify-start gap-6">
          <button className="p-4 rounded-xl bg-slate-300 flex items-center justify-center gap-2">
            <img src={interior} alt="" className="w-5" />
            <span className="">living room</span>
          </button>
          <button className="p-4 rounded-xl bg-slate-300 flex items-center justify-center gap-2">
            <img src={starBardaiIcons} alt="" className="w-5 " />
            <span className="">dark style </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default PromptDetails;
