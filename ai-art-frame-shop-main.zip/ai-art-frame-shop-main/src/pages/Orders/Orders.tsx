/* eslint-disable @typescript-eslint/no-unused-vars */
import { useEffect } from "react";
import axiosInstance from "../../utility/axiosInstace";
import { Link, useSearchParams } from "react-router-dom";
import useFetchOrders from "../../hooks/useFetchOrders";
import useQueryCards from "../../hooks/useQueryCards";

const Orders = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const isDelete = searchParams.get("delete");
  const orderId = searchParams.get("orderId");
  const paymentIntent = searchParams.get("payment_intent");
  const { orders, ordersRefetch } = useFetchOrders();
  const { cartsRefetch } = useQueryCards();
  // console.log("orders from hook", { orders });

  useEffect(() => {
    //!delete card from db if payment is successful
    const deleteCard = async () => {
      const response = await axiosInstance.delete(
        `/cart/${localStorage.getItem("uniqueId")}`,
        {
          headers: {
            orderId,
            paymentIntent,
          },
        }
      );
      ordersRefetch();
      cartsRefetch();
      setSearchParams({});
      console.log(response.data);
    };
    if (isDelete && orderId && paymentIntent) {
      deleteCard();
    }
  }, []);

  return (
    <div className="container mx-auto md:px-8 px-4 my-4 md:my-10 py-4 ">
      <div className="overflow-x-auto">
        <table className="table table-zebra">
          {/* head */}
          <thead>
            <tr>
              <th>#</th>
              <th>Order Id</th>
              <th>Delivery Status</th>
              <th>Order Status</th>
              <th>Price</th>
              <th> Payment Status </th>
              <th>Make Payment</th>
            </tr>
          </thead>
          <tbody>
            {orders &&
              orders.map((order, index) => (
                <tr key={order.id}>
                  <td>{index + 1}</td>
                  <td>{order.id}</td>
                  <td>{order.deliveryStatus}</td>
                  <td>{order.orderStatus}</td>
                  <td>
                    {order.totalPrice.allImagesPrice +
                      order.totalPrice.shippingFee}
                  </td>
                  <td>
                    <div className="">
                      {order.paymentStatus === "PAID" ? (
                        <>
                          <span className="text-green-500">Paid</span>
                          <p className="text-green-500">
                            {order.transactionId}
                          </p>
                        </>
                      ) : (
                        <span className="text-red-500">Not Paid</span>
                      )}
                    </div>
                  </td>
                  <td>
                    {order.paymentStatus === "PAID" ? (
                      <span className="text-green-500">Paid</span>
                    ) : (
                      <Link
                        to={`/payment?orderId=${
                          order.id
                        }&uniqueId=${localStorage.getItem("uniqueId")}`}
                        state={{ orderData: order }}
                        className="text-blue-500 hover:text-blue-700"
                      >
                        Pay Now
                      </Link>
                    )}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Orders;
