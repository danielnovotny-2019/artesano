/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { useForm } from "react-hook-form";
import InputField from "../../../shared/InputField/InputField";

const InputArea = () => {
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (data: any) => {
    console.log(data)
    // mutate(data);
    // console.log({ formState });
  };
  return (
   <form onSubmit={handleSubmit(onSubmit)}>
     <div className="mt-6 md:mt-12 space-y-8 font-inter">
      {/* name */}
      <InputField register={register}  errors={errors} name="name" required label="name" type="text" placeholder="Your Name"  />

      {/* email */}
      <InputField register={register}  errors={errors} name="email" required  label="email" type="email" placeholder="slamychadiy@gmail.com"  />

      {/* message */}
      <div className="">
        <label htmlFor="message" className="text-2xl md:text-[35px] font-medium">
        how can we help ?
        </label>
        <textarea
        rows={5}
          name="message"
          id="message"
          className="w-full block border-b-2 border-black border-l-0 border-t-0 focus:outline-none text-2xl py-4"
          placeholder="what do you want to tell us ?"
        />
      </div>

    
    </div>
    <button className="my-8 md:my-24 block w-full py-2  text-center text-white bg-black font-bebas text-5xl">
    contact us  
    </button>
   </form>
  );
};

export default InputArea;
