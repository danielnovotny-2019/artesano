import leftImage from "../../assets/contactUs/leftImage.svg";
import InputArea from "./InputArea/InputArea";
const ContactUs = () => {
  return (
    <div className="relative ">
      {" "}
      <div className="container mx-auto font-poppins ">
        <div className="grid grid-cols-1 md:grid-cols-2 initial-scale md:transform md:scale-75">
          <div className="=">
            <div className="p-8 px-12">
              <h2 className="text-6xl md:text-8xl font-bebas">
                Let’s get in{" "}
                <span className="font-crimson font-extrabold">@</span> <br />
                touch !
              </h2>
              <p className="text-2xl text-black/80">
                you can also reach us via{" "}
                <span className="text-black font-semibold">
                  contact@artesio.com
                </span>
              </p>

              {/* inputs */}
              <InputArea />
            </div>
          </div>
          <div className=" hidden md:block  "></div>
        </div>
      </div>
      <img
        src={leftImage}
        alt=""
        className="h-full w-full md:w-1/2 top-0 right-0 md:absolute object-cover"
      />
    </div>
  );
};

export default ContactUs;
