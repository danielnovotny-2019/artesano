import heroImage from "../../assets/AboutMe/hero.png";
import GalleryContainer from "../../components/GalleryContainer/GalleryContainer";
import Testimonial from "../../components/Testimonial/Testimonial";
const Gallery = () => {
  return (
    <div className="container mx-auto  md:px-8 px-4 py-4 font-poppins  ">
      <div className=" py-12 relative initial-scale md:transform md:scale-75">
        <div className="flex md:items-center items-center gap-16 md:flex-row flex-col  ">
          <div className=" md:flex-1 mb-8 ">
            <h1 className="text-7xl text-[#E84C46] md:text-[128px] font-bebas">
              Gallery
            </h1>
            <h4 className="text-3xl md:text-4xl text-black font-bebas">
              Make your own art!
            </h4>
            <p className="text-2xl text-black/80 font-inter">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing
              elit, sed do eiusmod tempor
            </p>
          </div>
          <div className="md:flex-1">
            <img src={heroImage} alt="" />
          </div>

          <div className="absolute -bottom-8 left-0 flex items-center justify-between gap-4">
            <Testimonial />
            <Testimonial />
            <Testimonial />
          </div>
        </div>
      </div>
      <div className="my-20">
        <GalleryContainer />
      </div>
    </div>
  );
};

export default Gallery;
