import { Link } from "react-router-dom";
import Accordion from "../../components/Home/Accordion/Accordion";
import BrandLogo from "../../components/Home/BrandLogo/BrandLogo";
import Hero from "../../components/Home/Hero/Hero";
import Process from "../../components/Home/Process/Process";
import VideoSection from "../../components/Home/VideoSection/VideoSection";

const Home = () => {
  return (
    <div className=" ">
      <div className="container mx-auto md:px-8 px-4 my-4 md:my-10 py-4">
        <Hero />
        <div className="md:hidden flex items-center justify-center gap-4">
          <button className="py-[6.5px] px-[18px] text-white bg-black text-[7px] font-semibold">
            Learn more
          </button>
          <Link
            to={"/generate"}
            className="py-[6.5px] px-[18px] text-black bg-white border-[1.2px] border-black text-[7px] font-semibold"
          >
            {" "}
            Design now
          </Link>
        </div>
      </div>
      <BrandLogo />
      <div className="container mx-auto md:px-8 px-4 my-4 md:my-10 py-4">
        <VideoSection />
      </div>
      <Process />

      <div className="bg-[#D9D9D9] md:py-16 p-4 md:my-10 my-5  ">
        <div className=" w-8/12 md:w-7/12 mx-auto initial-scale md:transform md:scale-75">
          <h3 className="text-center text-2xl md:text-6xl font-bebas">
            Frequently Asked Questions (FAQs) <br /> AI Art Creation and
            Printing
          </h3>
        </div>
      </div>
      <div className="container mx-auto md:px-8 px-4 my-4  py-4 ">
        <Accordion />
      </div>
    </div>
  );
};

export default Home;
