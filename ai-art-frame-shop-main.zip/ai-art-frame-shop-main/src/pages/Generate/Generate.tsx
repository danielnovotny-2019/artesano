/* eslint-disable @typescript-eslint/no-explicit-any */
import Prompt from "../../components/Generate/Prompt";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination } from "swiper/modules";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import ImageCard from "../../components/Generate/ImageCard/ImageCard";
import usePrompt from "../../hooks/usePrompt";
import Loader from "../../shared/Loader/Loader";

const Generate = () => {
  const { mutate, data, isError, isLoading } = usePrompt();
  const pagination = {
    clickable: true,
    renderBullet: function (_index: number, className: string) {
      return `<span class=' ${className} '></span>`;
    },
  };
  const aiGeneratedImages = data?.userGeneratedImages.images;
  // console.log(aiGeneratedImages, { data, isError, isLoading });
  return (
    <div className="container mx-auto md:px-8 px-4 my-4 md:my-10 py-4 font-poppins min-h-screen ">
      <Prompt mutate={mutate} />
      {isLoading && !isError && (
        <>
          <Loader />
        </>
      )}

      {!isLoading && !isError && (
        <>
          {data && (
            <>
              {/* desktop */}
              <div className=" grid-cols-1 md:grid-cols-2 gap-16 my-6 md:my-12 py-6 md:py-10 hidden md:grid">
                {aiGeneratedImages?.map(
                  (imageUrl: string, index: number, fullArray: string[]) => {
                    // const variants = fullArray.map((imgUrl) => imgUrl.b64_json);

                    return (
                      <ImageCard
                        imageUrl={imageUrl}
                        key={`${data?.userGeneratedImages?.id}-${index}`}
                        variants={fullArray}
                      />
                    );
                  }
                )}
              </div>

              {/* mobile */}
              <div className=" my-6 md:hidden">
                <>
                  <Swiper
                    pagination={pagination}
                    modules={[Pagination]}
                    /*   autoplay={{ //? if you use autoplay you need to import Autoplay module and add it to the array above
                      delay: 1500,
                      disableOnInteraction: false,
                    }} */
                    className=""
                  >
                    {aiGeneratedImages?.map(
                      (
                        imageUrl: string,
                        index: number,
                        fullArray: string[]
                      ) => {
                        // const variants = fullArray.map((imgUrl) => imgUrl.url);
                        return (
                          <SwiperSlide
                            key={`${data?.userGeneratedImages?.id}-${index}`}
                          >
                            {" "}
                            <ImageCard
                              imageUrl={imageUrl}
                              variants={fullArray}
                            />
                          </SwiperSlide>
                        );
                      }
                    )}
                  </Swiper>
                </>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default Generate;
