/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from "react";
import BannerSection from "../../components/cart/BannerSection/BannerSection";
import BillingForm from "../../components/cart/BillingForm/BillingForm";
import PriceSection from "../../components/cart/PriceSection/PriceSection";
import { CheckAllFieldsType, PriceType } from "../../types/types";
// import { useCard } from "../../Provider/CardProvider";
// import useQueryCards from "../../hooks/useQueryCards";
import { useCard } from "../../Provider/CardProvider";

const Cart = () => {
  const { cartsData } = useCard();
  // const [orderImages, setOrderImages] = useState<OrderedImage[]>([]);
  const [price, setPrice] = useState<PriceType>({
    shippingFee: 10,
    allImagesPrice: 0,
  });
  const [error, setError] = useState<string>("");
  const [checkAllFields, setCheckAllFields] = useState<CheckAllFieldsType[]>(
    []
  );

  // const handleTotalPrice = (price: number) => {};
  // console.log({ orderImages, subTotal });

  useEffect(() => {
    const totalPrice = cartsData?.reduce((acc, item) => {
      // Extract prices from each card image in the cardImages array
      const cardImagePrices = item.cardImages.map(
        (cardImage) => cardImage.subTotal || 0
      );

      // Sum up the prices for the current item
      const itemTotalPrice = cardImagePrices.reduce(
        (itemAcc, price) => itemAcc + (price || 0),
        0
      );

      // Add the item's total price to the accumulator
      return acc + itemTotalPrice;
    }, 0);

    setPrice({ ...price, allImagesPrice: totalPrice });
  }, [cartsData]);

  console.log(cartsData);
  return (
    <div className="container mx-auto md:px-8 px-4 my-4 md:my-10 py-4 font-poppins  ">
      <h1 className="text-center md:text-8xl text-6xl font-bebas text-black initial-scale md:transform md:scale-75">
        shopping cart
      </h1>
      <hr className="border-black" />
      {cartsData?.map((cartData) => (
        <BannerSection
          variants={cartData.variants}
          key={cartData?.id}
          cardImages={cartData.cardImages}
          cartId={cartData?.id}
          setCheckAllFields={setCheckAllFields}
        />
      ))}

      <PriceSection
        price={price}
        error={error}
        setError={setError}
        checkAllFields={checkAllFields}
      />

      <BillingForm cartsData={cartsData} error={error} price={price} />
      {/* <PaypalPayment /> */}
    </div>
  );
};

export default Cart;
