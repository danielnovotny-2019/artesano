import { useEffect, useState } from "react";
import axiosInstance from "../../utility/axiosInstace";
import { useLocation } from "react-router-dom";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import CheckoutForm from "../../components/payment/CheckoutForm";

// This is your test publishable API key.
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

const Payment = () => {
  const location = useLocation();
  const { orderData } = location.state;
  const [clientSecret, setClientSecret] = useState("");
  // console.log('REACT_STRIPE_PUBLISHABLE_KEY',import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY)
  useEffect(() => {
    const sendInitialPayment = async () => {
      // console.log('first payment')
      const response = await axiosInstance.post("/payment", orderData);
      setClientSecret(response.data.client_secret);
      // console.log(response.data);
    };

    if (orderData) {
      sendInitialPayment();
    }
  }, []);

  const appearance = {
    theme: "stripe" as const,
  };
  const options = {
    clientSecret,
    appearance,
  };

  // console.log(orderData)

  return (
    <div className="h-screen flex-col gap-8 w-full flex items-center justify-center ">
      <h1 className="text-center text-4xl text-gray-900 font-bold">
        You are paying{" "}
        {orderData?.totalPrice.allImagesPrice +
          orderData?.totalPrice.shippingFee}
        $
      </h1>
      {clientSecret && (
        <Elements options={options} stripe={stripePromise}>
          <CheckoutForm orderData={orderData} clientSecret={clientSecret} />
        </Elements>
      )}
    </div>
  );
};

export default Payment;
