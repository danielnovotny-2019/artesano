function shuffleString(inputString: string): string {
    const array = inputString.split('');
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array.join('');
  }
  
  function generateUniqueID(): string {
    const timestamp = Date.now().toString();
    const randomPart = Math.random().toString(36).substring(2, 10); // Random 8 characters
    const uniqueID = timestamp + randomPart;
  
    if (uniqueID.length < 24) {
      // If the combined string is less than 24 characters, pad it with more random characters.
      const paddingLength = 24 - uniqueID.length;
      const padding = Array(paddingLength)
        .fill(null)
        .map(() => Math.random().toString(36).charAt(2))
        .join('');
      return shuffleString(uniqueID + padding);
    }
  
    return shuffleString(uniqueID.substring(0, 24)); // Truncate to 24 characters if longer
  }
  
  export default generateUniqueID