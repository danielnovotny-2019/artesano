import { CardImage } from "../types/types";
import axiosInstance from "./axiosInstace";

const updateCart = async (
  updatedImages: CardImage,
  cardId: string,
  cardImageId: string
) => {
  try {
    // console.log(updatedImages)
    const response = await axiosInstance.put(`/cart/${cardId}`, {
      cardImageId,
      updatedImages,
    });
    console.log("response", response);
  } catch (error) {
    console.log("error", error);
  }
};

export default updateCart;
