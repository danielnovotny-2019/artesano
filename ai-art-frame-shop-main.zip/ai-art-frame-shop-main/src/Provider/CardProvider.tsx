/* eslint-disable react-refresh/only-export-components */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, {
  FC,
  createContext,
  useContext,
  useEffect,
  useReducer,
} from "react";
import { CardTypeDB } from "../types/types";
import useQueryCards from "../hooks/useQueryCards";
import {
  UPDATE_All,
  UPDATE_MARTIAL,
  UPDATE_QUANTITY,
  UPDATE_SIZE_PRICE,
  DELETE_ITEM,
} from "../constant/constant";
import updateCart from "../utility/updateCard";

interface CardProviderProps {
  children: React.ReactNode;
}

interface CardContextType {
  cartsData: CardTypeDB[];
  handleFieldChange: (field: string, value: any) => void; // Replace 'any' with the appropriate type for value
}

const CardContext = createContext<CardContextType | undefined>(undefined);

// Define the initial state
const initialState: CardTypeDB[] = [
  {
    cardImages: [],
    uniqueId: "",
    id: "",
    variants: [],
  },
];

// Reducer function
function reducer(state: CardTypeDB[], action: any): CardTypeDB[] {
  switch (action.type) {
    case UPDATE_All:
      return action.payload;

    case UPDATE_MARTIAL:
    case UPDATE_SIZE_PRICE:
    case UPDATE_QUANTITY: {
      const updatedState = state.map((card) => {
        if (card.id === action.payload.cartId) {
          const updatedImages = card.cardImages.map((image) => {
            if (image.id === action.payload.cartImage.id) {
              // Update the specified properties based on the action type
              if (action.type === UPDATE_MARTIAL) {
                //! send request to update the cart on the server
                const updatedImage = {
                  ...image,
                  material: action.payload.material,
                };
                updateCart(
                  updatedImage,
                  action.payload.cartId,
                  action.payload.cartImage.id
                );
                return updatedImage;
              } else if (action.type === UPDATE_SIZE_PRICE) {
                const updatedImage = {
                  ...image,
                  size: action.payload.selectedSizePrice.size,
                  price: action.payload.selectedSizePrice.price,
                  subTotal: action.payload.selectedSizePrice.subTotal,
                };
                //! send request to update the cart on the server
                updateCart(
                  updatedImage,
                  action.payload.cartId,
                  action.payload.cartImage.id
                );
                return updatedImage;
              } else if (action.type === UPDATE_QUANTITY) {
                const updatedImage = {
                  ...image,
                  numberOfImage: action.payload.numberOfImage,
                };
                //! send request to update the cart on the server
                updateCart(
                  updatedImage,
                  action.payload.cartId,
                  action.payload.cartImage.id
                );
                return updatedImage;
              }
            }

            return image;
          });

          return { ...card, cardImages: updatedImages };
        }

        return card;
      });

      // Update the cart on the server
      // updateCart(image, action.payload.cartId, action.payload.cartImage.id);
      return updatedState;
    }
    case DELETE_ITEM: {
      // Filter out the item to be deleted
      //! send request to delete the cart on the server
      
      const updatedState = state.map((card) => {
        if (card.id === action.payload.cartId) {
          const updatedImages = card.cardImages.filter(
            (image) => image.id !== action.payload.cartImage.id
          );
          return { ...card, cardImages: updatedImages };
        }
        return card;
      });
      return updatedState;
    }
    default:
      return state;
  }
}

// Card provider hook
export const useCard = () => {
  const context = useContext(CardContext);
  if (!context) {
    throw new Error("useCard must be used within a CardProvider");
  }
  return context;
};

const CardProvider: FC<CardProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { cartsData } = useQueryCards();
  // const { cartsData, cartsError, cartsIsLoading, cartsRefetch } =
  //   useQueryCards();

  // Common handleFieldChange function
  const handleFieldChange = (type: string, payload: any) => {
    dispatch({ type, payload });
  };

  const value: CardContextType = {
    cartsData: state,
    handleFieldChange,
  };

  // fetch initial data from API
  useEffect(() => {
    // dispatch({ type: UPDATE_All, payload: cartsData });
    if (cartsData) {
      handleFieldChange(UPDATE_All, cartsData);
    }
  }, [cartsData]);

  // console.log("context api", value);
  return <CardContext.Provider value={value}>{children}</CardContext.Provider>;
};

export default CardProvider;
