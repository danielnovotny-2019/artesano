import { FieldErrors, FieldValues, UseFormRegister } from "react-hook-form";

/* eslint-disable @typescript-eslint/no-explicit-any */
export interface SectionTitleProps {
  title: string;
  description: string;
  star?: boolean;
}

export interface InputFieldProps {
  label: string;
  placeholder: string;
  type: string;
  classNames?: string;
  register: UseFormRegister<FieldValues>;
  errors: FieldErrors<FieldValues>;
  required?: boolean;
  name: string;
}

export interface PromptType {
  prompt: string;
  aspectRatio: string;
  generatorApi: string;
  styleTags?: string;
}
export interface SizePrice {
  size: string;
  price: number;
  subTotal?: number;

}

export interface Material {
  material: string;
  sizePrice: SizePrice[];
}

export interface AddressType {
  country: string;
  zipCode: string;
  city: string;
  streetNumber: string;
  additionalNotes?: string | null;
}
export interface UserType {
  id?: string;
  email: string;
  name: string;
  surname: string;
  company?: string | null;
  uniqueId: string;
  additionalNotes?: string | null;
  address: AddressType;
  order?: OrderType[];
}

export interface OrderType {
  id?: string;
  orderedImages: CardImage[];
  cardIds: string[];
  deliveryStatus: "PROCESSING" | "PACkAGING" | "SHIPPING" | "DELIVERED";
  uniqueId: string;
  paymentMethod: string;
  paymentStatus: "PAID" | "UNPAID";
  orderStatus: "PADDING" | "APPROVED" | "REJECTED";
  totalPrice: PriceType;
  transactionId?: string | null;
}

export interface CartType {
  id: string;
  material?: string | null;
  format?: string | null;
  generationModel: string;
  author?: UserType | null;
  authorId?: string | null;
  images: string[];
  variants: string[];
  deliveryPeriod: string;
  uniquid: string;
}

export interface OrderedImage {
  material: string;
  format?: string | null;
  size: string;
  price: number;
  orderId: string;
  images: string[];
}

export interface PriceType {
  shippingFee: number;
  allImagesPrice: number;
}

export type NewOrderType = {
  userData: UserType;
  orderData: OrderType;
};

export type CardTypeDB = {
  id: string;
  cardImages: CardImage[];
  variants: string[];
  uniqueId: string;
};

export type CardImage = {
  id?: string;
  imagesUrl: string;
  material?: string;
  format?: string;
  generationModel: string;
  deliveryPeriod: string;
  numberOfImage?: number;
  size?: string;
  price?: number;
  subTotal?: number;
};

export interface BannerSectionProps {
  cardImages: CardImage[];
  cartId: string;
  cartImage: CardImage;
  variants?: string[];
  index: number;
  setCheckAllFields: React.Dispatch<React.SetStateAction<CheckAllFieldsType[]>>;
}

export type CheckAllFieldsType ={
  imageCardId?: string;
  material?: string;
  size?: string;
}