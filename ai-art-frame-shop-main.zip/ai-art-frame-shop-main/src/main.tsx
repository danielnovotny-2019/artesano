import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { RouterProvider } from "react-router-dom";
import router from "./router/Router.jsx";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { PayPalScriptProvider } from "@paypal/react-paypal-js";
import CardProvider from "./Provider/CardProvider.js";

// Create a client
const queryClient = new QueryClient();

// paypal initial options
const initialOptions = {
  clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
  currency: "USD",
  intent: "capture",
  components: "buttons",
};

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <PayPalScriptProvider options={initialOptions}>
      <QueryClientProvider client={queryClient}>
        <CardProvider>
          <RouterProvider router={router} />
        </CardProvider>
      </QueryClientProvider>
    </PayPalScriptProvider>
  </React.StrictMode>
);

/**
 * interface MyPayPalScriptProviderProps extends ScriptProviderProps {
  initialOptions: {
    "client-id": string;
    currency: string;
    intent: string;
  };
}

// ...

<PayPalScriptProvider initialOptions={initialOptions} {...otherProps}>
</PayPalScriptProvider>
 */
